﻿namespace sistema
{
    partial class mdiPrejeto
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            toolTip = new ToolTip(components);
            label1 = new Label();
            lbProduto = new Label();
            lbParametroEstoque = new Label();
            lbCat = new Label();
            lbNV = new Label();
            lbFornecedor = new Label();
            pictureBox1 = new PictureBox();
            pictureBox2 = new PictureBox();
            pictureBox3 = new PictureBox();
            pictureBox4 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.FromArgb(21, 96, 130);
            label1.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.White;
            label1.Location = new Point(98, 360);
            label1.Name = "label1";
            label1.Size = new Size(37, 19);
            label1.TabIndex = 5;
            label1.Text = "Sair";
            label1.Click += label1_Click;
            // 
            // lbProduto
            // 
            lbProduto.AutoSize = true;
            lbProduto.BackColor = Color.FromArgb(21, 96, 130);
            lbProduto.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point);
            lbProduto.ForeColor = Color.White;
            lbProduto.Location = new Point(74, 163);
            lbProduto.Name = "lbProduto";
            lbProduto.Size = new Size(74, 19);
            lbProduto.TabIndex = 1;
            lbProduto.Text = "Produtos";
            lbProduto.Click += lbProduto_Click_1;
            // 
            // lbParametroEstoque
            // 
            lbParametroEstoque.AutoSize = true;
            lbParametroEstoque.BackColor = Color.FromArgb(21, 96, 130);
            lbParametroEstoque.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point);
            lbParametroEstoque.ForeColor = Color.White;
            lbParametroEstoque.Location = new Point(27, 317);
            lbParametroEstoque.Name = "lbParametroEstoque";
            lbParametroEstoque.Size = new Size(186, 19);
            lbParametroEstoque.TabIndex = 2;
            lbParametroEstoque.Text = "Parâmetros de estoque";
            lbParametroEstoque.Click += lbParametroEstoque_Click_1;
            // 
            // lbCat
            // 
            lbCat.AutoSize = true;
            lbCat.BackColor = Color.FromArgb(21, 96, 130);
            lbCat.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point);
            lbCat.ForeColor = Color.White;
            lbCat.Location = new Point(65, 206);
            lbCat.Name = "lbCat";
            lbCat.Size = new Size(93, 19);
            lbCat.TabIndex = 3;
            lbCat.Text = "Categorias";
            lbCat.Click += lbCat_Click;
            // 
            // lbNV
            // 
            lbNV.AutoSize = true;
            lbNV.BackColor = Color.FromArgb(21, 96, 130);
            lbNV.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point);
            lbNV.ForeColor = Color.White;
            lbNV.Location = new Point(47, 274);
            lbNV.Name = "lbNV";
            lbNV.Size = new Size(131, 19);
            lbNV.TabIndex = 4;
            lbNV.Text = "Nivel de serviço";
            lbNV.Click += lbNV_Click_1;
            // 
            // lbFornecedor
            // 
            lbFornecedor.AutoSize = true;
            lbFornecedor.BackColor = Color.FromArgb(21, 96, 130);
            lbFornecedor.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point);
            lbFornecedor.ForeColor = Color.White;
            lbFornecedor.Location = new Point(47, 243);
            lbFornecedor.Name = "lbFornecedor";
            lbFornecedor.Size = new Size(114, 19);
            lbFornecedor.TabIndex = 0;
            lbFornecedor.Text = "Fornecedores";
            lbFornecedor.Click += lbFornecedor_Click_1;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.fechar;
            pictureBox1.Location = new Point(1475, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(109, 83);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 4;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.BackColor = Color.FromArgb(21, 96, 130);
            pictureBox2.Dock = DockStyle.Left;
            pictureBox2.Image = Properties.Resources.Login1;
            pictureBox2.Location = new Point(0, 0);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(226, 527);
            pictureBox2.TabIndex = 6;
            pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.BackColor = Color.FromArgb(21, 96, 130);
            pictureBox3.Image = Properties.Resources.Cindy_1;
            pictureBox3.Location = new Point(80, 52);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(68, 65);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 7;
            pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            pictureBox4.BackColor = Color.AliceBlue;
            pictureBox4.BackgroundImage = Properties.Resources.of;
            pictureBox4.BackgroundImageLayout = ImageLayout.Center;
            pictureBox4.Dock = DockStyle.Fill;
            pictureBox4.Location = new Point(226, 0);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(1234, 527);
            pictureBox4.TabIndex = 8;
            pictureBox4.TabStop = false;
            // 
            // mdiPrejeto
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoValidate = AutoValidate.Disable;
            BackColor = Color.Black;
            ClientSize = new Size(1460, 527);
            ControlBox = false;
            Controls.Add(pictureBox4);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox1);
            Controls.Add(label1);
            Controls.Add(lbProduto);
            Controls.Add(lbParametroEstoque);
            Controls.Add(lbFornecedor);
            Controls.Add(lbCat);
            Controls.Add(lbNV);
            Controls.Add(pictureBox2);
            FormBorderStyle = FormBorderStyle.None;
            IsMdiContainer = true;
            Margin = new Padding(4, 3, 4, 3);
            Name = "mdiPrejeto";
            ShowIcon = false;
            Text = "mdiPrejeto";
            WindowState = FormWindowState.Maximized;
            Load += mdiPrejeto_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }
        #endregion

        private System.Windows.Forms.ToolTip toolTip;
        private Label lbFornecedor;
        private Label lbProduto;
        private Label lbNV;
        private Label lbCat;
        private Label lbParametroEstoque;
        private Label label1;
        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
        private PictureBox pictureBox4;
    }
}



