﻿namespace sistemaLogin
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel2 = new Panel();
            label4 = new Label();
            pictureBox1 = new PictureBox();
            label5 = new Label();
            btnEntrar = new Button();
            btnSair = new Button();
            txtNome = new TextBox();
            label6 = new Label();
            label7 = new Label();
            txtSenha = new TextBox();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // panel2
            // 
            panel2.BackColor = Color.White;
            panel2.Controls.Add(label4);
            panel2.Location = new Point(-1, 1);
            panel2.Name = "panel2";
            panel2.Size = new Size(106, 173);
            panel2.TabIndex = 10;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.White;
            label4.Font = new Font("Century Gothic", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            label4.ForeColor = Color.FromArgb(21, 96, 130);
            label4.Location = new Point(9, 76);
            label4.Name = "label4";
            label4.Size = new Size(90, 18);
            label4.TabIndex = 2;
            label4.Text = "Bem vindo!";
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.White;
            pictureBox1.Image = sistema.Properties.Resources.Login;
            pictureBox1.Location = new Point(-1, -2);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(264, 176);
            pictureBox1.TabIndex = 11;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.FromArgb(21, 96, 130);
            label5.Font = new Font("Century Gothic", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            label5.ForeColor = Color.White;
            label5.Location = new Point(155, 20);
            label5.Name = "label5";
            label5.Size = new Size(59, 23);
            label5.TabIndex = 12;
            label5.Text = "Login";
            // 
            // btnEntrar
            // 
            btnEntrar.Font = new Font("Century Gothic", 8.25F, FontStyle.Regular, GraphicsUnit.Point);
            btnEntrar.ForeColor = Color.FromArgb(21, 96, 130);
            btnEntrar.Location = new Point(157, 132);
            btnEntrar.Name = "btnEntrar";
            btnEntrar.Size = new Size(48, 24);
            btnEntrar.TabIndex = 13;
            btnEntrar.Text = "Entrar";
            btnEntrar.UseVisualStyleBackColor = true;
            // 
            // btnSair
            // 
            btnSair.Font = new Font("Century Gothic", 8.25F, FontStyle.Regular, GraphicsUnit.Point);
            btnSair.ForeColor = Color.FromArgb(21, 96, 130);
            btnSair.Location = new Point(211, 132);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(43, 24);
            btnSair.TabIndex = 18;
            btnSair.Text = "Sair";
            btnSair.UseVisualStyleBackColor = true;
            // 
            // txtNome
            // 
            txtNome.Location = new Point(171, 63);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(83, 23);
            txtNome.TabIndex = 14;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.FromArgb(21, 96, 130);
            label6.Font = new Font("Century Gothic", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label6.ForeColor = Color.White;
            label6.Location = new Point(117, 98);
            label6.Name = "label6";
            label6.Size = new Size(55, 17);
            label6.TabIndex = 17;
            label6.Text = "Senha: ";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.FromArgb(21, 96, 130);
            label7.Font = new Font("Century Gothic", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label7.ForeColor = Color.White;
            label7.Location = new Point(110, 69);
            label7.Name = "label7";
            label7.Size = new Size(62, 17);
            label7.TabIndex = 15;
            label7.Text = "Usuário: ";
            // 
            // txtSenha
            // 
            txtSenha.Location = new Point(171, 96);
            txtSenha.Name = "txtSenha";
            txtSenha.Size = new Size(83, 23);
            txtSenha.TabIndex = 16;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(263, 175);
            Controls.Add(btnEntrar);
            Controls.Add(btnSair);
            Controls.Add(txtNome);
            Controls.Add(label6);
            Controls.Add(label7);
            Controls.Add(txtSenha);
            Controls.Add(label5);
            Controls.Add(panel2);
            Controls.Add(pictureBox1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Panel panel2;
        private Label label4;
        private PictureBox pictureBox1;
        private Label label5;
        private Button btnEntrar;
        private Button btnSair;
        private TextBox txtNome;
        private Label label6;
        private Label label7;
        private TextBox txtSenha;
    }
}