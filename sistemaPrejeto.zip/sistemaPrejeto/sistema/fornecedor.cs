﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Data;
using System.Data.SqlClient;

namespace sistema
{
    public partial class fornecedor : Form
    {
        public fornecedor()
        {
            InitializeComponent();
        }

        string strConexao = "" +
                "Data Source=localhost;" +
                "Initial Catalog=sistema;" +
                "User ID=sa;" +
                "Password=123456";

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Conexao()
        {
            SqlConnection conn = new SqlConnection(strConexao);

            try
            {
                conn.Open();
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro " + ex.ToString());
                Application.Exit();
            }
        }

        private void txtNome_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtEndereco_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtTell_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtEmail_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtTempoAtendimentoSku_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtCnpj_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtRazaoSocial_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtUf_TextChanged(object sender, EventArgs e)
        {

        }

        //private void txtInscricaoEstadual_TextChanged(object sender, EventArgs e)
        private void txtInscriçãoEstadual_TextChanged(object sender, EventArgs e)
        //private void txtInscricaoEstadual_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtObs_TextChanged(object sender, EventArgs e)
        {

        }

        private void cboStatus_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            if (ValidarDados() == false)
            {
                return;
            }
            string sql = "insert into fornecedor" +
                "(" +
                    "nome_fornecedor," +
                    "endereco_fornecedor," +
                    "telefone_fornecedor," +
                    "email_fornecedor," +
                    "tempo_sku_fornecedor," +
                    "cnpj_fornecedor," +
                    "razao_social_fornecedor," +
                    "uf_fornecedor," +
                    "inscricao_estadual_fornecedor," +
                    "obs_fornecedor," +
                    "status_fornecedor " +
                ")" +
                "values" +
                "(" +
                    "'" + txtNome.Text + "'," +
                    "'" + txtEndereco.Text + "'," +
                    "'" + mskTell.Text + "'," +
                    "'" + txtEmail.Text + "'," +
                    "'" + txtTempoAtendimentoSku.Text + "'," +
                    "'" + mskCnpj.Text + "'," +
                    "'" + txtRazaoSocial.Text + "'," +
                    "'" + txtUf.Text + "'," +
                    "'" + txtInscricaoEstadual.Text + "'," +
                    "'" + txtObs.Text + "'," +
                    "'" + cboStatus.Text + "'" +
                ")select SCOPE_IDENTITY()";

            SqlConnection conexao = new SqlConnection(strConexao);
            SqlCommand cmd = new SqlCommand(sql, conexao);
            cmd.CommandType = CommandType.Text;
            SqlDataReader reader;
            conexao.Open();

            try
            {
                reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    MessageBox.Show("Cadastro realizado com sucesso");

                    btnLimpar.PerformClick();
                    txtCodigo.Text = reader[0].ToString();
                    btnPesquisar.PerformClick();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());

            }
            finally
            {
                conexao.Close();
            }
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            if (ValidarDados() == false)
            {
                return;
            }

            string sql = "update fornecedor set " +
               "nome_fornecedor = '" + txtNome.Text + "'," +
               "endereco_fornecedor = '" + txtEndereco.Text + "', " +
               "telefone_fornecedor = '" + mskTell.Text + "', " +
               "email_fornecedor = '" + txtEmail.Text + "', " +
               "tempo_sku_fornecedor = '" + txtTempoAtendimentoSku.Text + "', " +
               "cnpj_fornecedor = '" + mskCnpj.Text + "', " +
               "razao_social_fornecedor ='" + txtRazaoSocial.Text + "', " +
               "uf_fornecedor = '" + txtUf.Text + "', " +
               "obs_fornecedor = '" + txtObs.Text + "', " +
               "status_fornecedor = '" + cboStatus.Text + "' " +
               "where id_fornecedor = " + txtCodigo.Text;

            SqlConnection conn = new SqlConnection(strConexao);
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.CommandType = CommandType.Text;

            try
            {
                conn.Open();

                int i = cmd.ExecuteNonQuery();
                if (i == 1)
                {
                    MessageBox.Show("Alteração feita com sucesso");

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro: " + ex.ToString());
            }
            finally
            {
                conn.Close();
            }
        }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {
            if (txtCodigo.Text == "")
            {
                MessageBox.Show("Coloque o ID");
                return;
            }

            string sql = "select * from fornecedor where id_fornecedor = " + txtCodigo.Text;

            SqlConnection conexao = new SqlConnection(strConexao);
            SqlCommand cmd = new SqlCommand(sql, conexao);
            cmd.CommandType = CommandType.Text;
            SqlDataReader reader;
            conexao.Open();

            try
            {
                reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    txtCodigo.Text = reader[0].ToString();
                    txtNome.Text = reader[1].ToString();
                    txtEndereco.Text = reader[2].ToString();
                    mskTell.Text = reader[3].ToString();
                    txtEmail.Text = reader[4].ToString();
                    txtTempoAtendimentoSku.Text = reader[5].ToString();
                    mskCnpj.Text = reader[6].ToString();
                    txtRazaoSocial.Text = reader[7].ToString();
                    txtUf.Text = reader[8].ToString();
                    txtInscricaoEstadual.Text = reader[9].ToString();
                    cboStatus.Text = reader[10].ToString();
                    txtObs.Text = reader[11].ToString();
                }
                else
                {
                    MessageBox.Show("Código do usuario inexistente!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                conexao.Close();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNome.Text = "";
            txtEndereco.Text = "";
            mskTell.Text = "";
            txtEmail.Text = "";
            txtTempoAtendimentoSku.Text = "";
            mskCnpj.Text = "";
            txtRazaoSocial.Text = "";
            txtUf.Text = "";
            txtInscricaoEstadual.Text = "";
            cboStatus.Text = "";
            txtObs.Text = "";
            txtCodigo.Text = "";
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            string sql = "delete from fornecedor where id_fornecedor = " + txtCodigo.Text;
            SqlConnection conn = new SqlConnection(strConexao);
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.CommandType = CommandType.Text;

            try
            {
                conn.Open();

                int i = cmd.ExecuteNonQuery();
                if (i > 0)
                {
                    MessageBox.Show("Cadastro excluido sucesso");
                    btnLimpar.PerformClick();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro: " + ex.ToString);

            }
            finally
            {
                conn.Close();
            }
        }

        private void conexao()
        {
            SqlConnection conn = new SqlConnection(strConexao);

            try
            {
                conn.Open();
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro " + ex.ToString());
                Application.Exit();
            }
        }


        private void btnFechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void fornecedor_Load(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        int n1;
        private bool ValidarDados()
        {
            if (int.TryParse(txtNome.Text, out n1) == true)
            {
                MessageBox.Show("Campo deve conter o nome!");
                txtNome.Text = "";
                txtNome.Focus();
                return false;
            }

            if (txtNome.Text == "")
            {
                MessageBox.Show("Campo deve ser preenchido!");
                txtNome.Text = "";
                txtNome.Focus();
                return false;
            }

            /////////////////////////////////////////////////////////////////////////////////////////

            if (int.TryParse(txtEndereco.Text, out n1) == true)
            {
                MessageBox.Show("Campo deve conter o endereço!");
                txtEndereco.Text = "";
                txtEndereco.Focus();
                return false;
            }

            if (txtEndereco.Text == "")
            {
                MessageBox.Show("Campo deve ser preenchido!");
                txtEndereco.Text = "";
                txtEndereco.Focus();
                return false;
            }

            /////////////////////////////////////////////////////////////////////////////////////////

            if (int.TryParse(mskTell.Text, out n1) == true)
            {
                MessageBox.Show("Campo deve ser numerico!");
                mskTell.Text = "";
                mskTell.Focus();
                return false;
            }

            if (mskTell.Text == "")
            {
                MessageBox.Show("Campo deve ser preenchido!");
                mskTell.Text = "";
                mskTell.Focus();
                return false;
            }

            if (mskTell.Text.Length < 11 || mskTell.Text.Length > 11)
            {
                MessageBox.Show("Campo deve ser preenchido corretamente!");
                mskTell.Text = "";
                mskTell.Focus();
                return false;
            }

            /////////////////////////////////////////////////////////////////////////////////////////
            ///

            if (int.TryParse(txtEmail.Text, out n1) == true)
            {
                MessageBox.Show("Campo deve conter o email!");
                txtEmail.Text = "";
                txtEmail.Focus();
                return false;
            }

            if (txtEmail.Text == "")
            {
                MessageBox.Show("Campo deve ser preenchido!");
                txtEmail.Text = "";
                txtEmail.Focus();
                return false;
            }

            /////////////////////////////////////////////////////////////////////////////////////////
            ///

            if (int.TryParse(txtTempoAtendimentoSku.Text, out n1) == false)
            {
                MessageBox.Show("Campo deve ser numerico!");
                txtTempoAtendimentoSku.Text = "";
                txtTempoAtendimentoSku.Focus();
                return false;
            }

            if (txtTempoAtendimentoSku.Text == "")
            {
                MessageBox.Show("Campo deve ser preenchido!");
                txtTempoAtendimentoSku.Text = "";
                txtTempoAtendimentoSku.Focus();
                return false;
            }

            /////////////////////////////////////////////////////////////////////////////////////////
            ///

            if (int.TryParse(mskCnpj.Text, out n1) == true)
            {
                MessageBox.Show("Campo deve ser numerico!");
                mskCnpj.Text = "";
                mskCnpj.Focus();
                return false;
            }

            if (mskCnpj.Text == "")
            {
                MessageBox.Show("Campo deve ser preenchido!");
                mskCnpj.Text = "";
                mskCnpj.Focus();
                return false;
            }

            if (mskCnpj.Text.Length < 14 || mskCnpj.Text.Length > 14)
            {
                MessageBox.Show("Preencha corretamente os campos!");
                mskCnpj.Text = "";
                mskCnpj.Focus();
                return false;
            }

            /////////////////////////////////////////////////////////////////////////////////////////
            ///

            if (int.TryParse(txtRazaoSocial.Text, out n1) == true)
            {
                MessageBox.Show("Campo deve conter a razão social!");
                txtRazaoSocial.Text = "";
                txtRazaoSocial.Focus();
                return false;
            }

            if (txtRazaoSocial.Text == "")
            {
                MessageBox.Show("Campo deve ser preenchido!");
                txtRazaoSocial.Text = "";
                txtRazaoSocial.Focus();
                return false;
            }

            /////////////////////////////////////////////////////////////////////////////////////////


            if (int.TryParse(txtUf.Text, out n1) == true)
            {
                MessageBox.Show("Campo deve conter a UF!");
                txtUf.Text = "";
                txtUf.Focus();
                return false;
            }

            if (txtRazaoSocial.Text == "")
            {
                MessageBox.Show("Campo deve ser preenchido!");
                txtUf.Text = "";
                txtUf.Focus();
                return false;
            }

            if (txtUf.Text.Length > 2 || txtUf.Text.Length < 2)
            {
                MessageBox.Show("Preencha corretamente os campos");
                txtUf.Text = "";
                txtUf.Focus();
                return false;
            }

            /////////////////////////////////////////////////////////////////////////////////////////
            ///

            if (int.TryParse(txtInscricaoEstadual.Text, out n1) == true)
            {
                MessageBox.Show("Campo deve conter a inscrição estadual!");
                txtInscricaoEstadual.Text = "";
                txtInscricaoEstadual.Focus();
                return false;
            }

            if (txtInscricaoEstadual.Text == "")
            {
                MessageBox.Show("Campo deve ser preenchido!");
                txtInscricaoEstadual.Text = "";
                txtInscricaoEstadual.Focus();
                return false;
            }

            /////////////////////////////////////////////////////////////////////////////////////////
            ///

            return true;
        }

        private void mskTell_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void mskCnpj_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void groupBox4_Enter(object sender, EventArgs e)
        {

        }
    }
}
