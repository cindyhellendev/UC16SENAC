﻿namespace sistema
{
    partial class parametroEstoque
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnExportCsv = new Button();
            backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            backgroundWorker2 = new System.ComponentModel.BackgroundWorker();
            pictureBox1 = new PictureBox();
            groupBox4 = new GroupBox();
            groupBox5 = new GroupBox();
            cboStatus = new ComboBox();
            label8 = new Label();
            cboIdProduto = new ComboBox();
            cbValorProduto = new ComboBox();
            label12 = new Label();
            txtId = new TextBox();
            label13 = new Label();
            txtPontoPedido = new TextBox();
            label14 = new Label();
            txtIntervaloTempo = new TextBox();
            label15 = new Label();
            button1 = new Button();
            txtLec = new TextBox();
            label16 = new Label();
            txtIntervalorPedido = new TextBox();
            label17 = new Label();
            txtEstoqueMedio = new TextBox();
            label18 = new Label();
            txtEstoqueMaximo = new TextBox();
            label19 = new Label();
            txtEstoqueSeguranca = new TextBox();
            label20 = new Label();
            groupBox2 = new GroupBox();
            txtObs = new TextBox();
            label9 = new Label();
            groupBox3 = new GroupBox();
            label10 = new Label();
            label21 = new Label();
            btnExcluir = new Button();
            btnLimpar = new Button();
            btnPesquisar = new Button();
            btnAlterar = new Button();
            pictureBox2 = new PictureBox();
            label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            groupBox4.SuspendLayout();
            groupBox5.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // btnExportCsv
            // 
            btnExportCsv.Location = new Point(307, 60);
            btnExportCsv.Name = "btnExportCsv";
            btnExportCsv.Size = new Size(92, 29);
            btnExportCsv.TabIndex = 18;
            btnExportCsv.Text = "Exportar CSV";
            btnExportCsv.UseVisualStyleBackColor = true;
            btnExportCsv.Click += btnExportCsv_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.Captura_de_tela_2024_06_02_010232;
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(683, 92);
            pictureBox1.TabIndex = 22;
            pictureBox1.TabStop = false;
            // 
            // groupBox4
            // 
            groupBox4.Controls.Add(groupBox5);
            groupBox4.Controls.Add(txtPontoPedido);
            groupBox4.Controls.Add(label14);
            groupBox4.Controls.Add(txtIntervaloTempo);
            groupBox4.Controls.Add(label15);
            groupBox4.Controls.Add(button1);
            groupBox4.Controls.Add(txtLec);
            groupBox4.Controls.Add(label16);
            groupBox4.Controls.Add(txtIntervalorPedido);
            groupBox4.Controls.Add(label17);
            groupBox4.Controls.Add(txtEstoqueMedio);
            groupBox4.Controls.Add(label18);
            groupBox4.Controls.Add(txtEstoqueMaximo);
            groupBox4.Controls.Add(label19);
            groupBox4.Controls.Add(txtEstoqueSeguranca);
            groupBox4.Controls.Add(label20);
            groupBox4.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point);
            groupBox4.Location = new Point(0, 98);
            groupBox4.Name = "groupBox4";
            groupBox4.Size = new Size(683, 168);
            groupBox4.TabIndex = 23;
            groupBox4.TabStop = false;
            groupBox4.Text = ";";
            // 
            // groupBox5
            // 
            groupBox5.Controls.Add(cboStatus);
            groupBox5.Controls.Add(label8);
            groupBox5.Controls.Add(cboIdProduto);
            groupBox5.Controls.Add(cbValorProduto);
            groupBox5.Controls.Add(label12);
            groupBox5.Controls.Add(txtId);
            groupBox5.Controls.Add(label13);
            groupBox5.Location = new Point(483, 0);
            groupBox5.Name = "groupBox5";
            groupBox5.Size = new Size(200, 112);
            groupBox5.TabIndex = 18;
            groupBox5.TabStop = false;
            // 
            // cboStatus
            // 
            cboStatus.DropDownStyle = ComboBoxStyle.DropDownList;
            cboStatus.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            cboStatus.FormattingEnabled = true;
            cboStatus.Location = new Point(85, 74);
            cboStatus.Name = "cboStatus";
            cboStatus.Size = new Size(109, 28);
            cboStatus.TabIndex = 10;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label8.ForeColor = Color.FromArgb(21, 48, 65);
            label8.Location = new Point(40, 80);
            label8.Name = "label8";
            label8.Size = new Size(45, 16);
            label8.TabIndex = 19;
            label8.Text = "Status";
            // 
            // cboIdProduto
            // 
            cboIdProduto.DropDownStyle = ComboBoxStyle.DropDownList;
            cboIdProduto.FormattingEnabled = true;
            cboIdProduto.Location = new Point(85, 15);
            cboIdProduto.Name = "cboIdProduto";
            cboIdProduto.Size = new Size(55, 24);
            cboIdProduto.TabIndex = 2;
            // 
            // cbValorProduto
            // 
            cbValorProduto.FormattingEnabled = true;
            cbValorProduto.Location = new Point(146, 15);
            cbValorProduto.Name = "cbValorProduto";
            cbValorProduto.Size = new Size(48, 24);
            cbValorProduto.TabIndex = 17;
            cbValorProduto.Visible = false;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label12.ForeColor = Color.FromArgb(21, 48, 65);
            label12.Location = new Point(120, 51);
            label12.Name = "label12";
            label12.Size = new Size(20, 16);
            label12.TabIndex = 0;
            label12.Text = "ID";
            label12.TextAlign = ContentAlignment.TopCenter;
            // 
            // txtId
            // 
            txtId.Location = new Point(146, 45);
            txtId.Name = "txtId";
            txtId.Size = new Size(48, 22);
            txtId.TabIndex = 1;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label13.ForeColor = Color.FromArgb(21, 48, 65);
            label13.Location = new Point(12, 18);
            label13.Name = "label13";
            label13.Size = new Size(73, 16);
            label13.TabIndex = 3;
            label13.Text = "Produto ID";
            // 
            // txtPontoPedido
            // 
            txtPontoPedido.Location = new Point(366, 74);
            txtPontoPedido.Name = "txtPontoPedido";
            txtPontoPedido.Size = new Size(111, 22);
            txtPontoPedido.TabIndex = 8;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.ForeColor = Color.FromArgb(21, 48, 65);
            label14.Location = new Point(261, 74);
            label14.Name = "label14";
            label14.Size = new Size(104, 16);
            label14.TabIndex = 16;
            label14.Text = "Ponto de Pedido";
            // 
            // txtIntervaloTempo
            // 
            txtIntervaloTempo.Location = new Point(128, 74);
            txtIntervaloTempo.Name = "txtIntervaloTempo";
            txtIntervaloTempo.Size = new Size(127, 22);
            txtIntervaloTempo.TabIndex = 6;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.ForeColor = Color.FromArgb(21, 48, 65);
            label15.Location = new Point(9, 74);
            label15.Name = "label15";
            label15.Size = new Size(122, 16);
            label15.TabIndex = 14;
            label15.Text = "Intervalo de Tempo";
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(21, 48, 65);
            button1.ForeColor = Color.White;
            button1.Location = new Point(613, 118);
            button1.Name = "button1";
            button1.Size = new Size(64, 37);
            button1.TabIndex = 0;
            button1.Text = "Salvar";
            button1.UseVisualStyleBackColor = false;
            // 
            // txtLec
            // 
            txtLec.Location = new Point(10, 128);
            txtLec.Name = "txtLec";
            txtLec.Size = new Size(467, 22);
            txtLec.TabIndex = 7;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.ForeColor = Color.FromArgb(21, 48, 65);
            label16.Location = new Point(9, 109);
            label16.Name = "label16";
            label16.Size = new Size(171, 16);
            label16.TabIndex = 12;
            label16.Text = "Lote Economico de Compra";
            // 
            // txtIntervalorPedido
            // 
            txtIntervalorPedido.Location = new Point(366, 45);
            txtIntervalorPedido.Name = "txtIntervalorPedido";
            txtIntervalorPedido.Size = new Size(111, 22);
            txtIntervalorPedido.TabIndex = 5;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.ForeColor = Color.FromArgb(21, 48, 65);
            label17.Location = new Point(237, 46);
            label17.Name = "label17";
            label17.Size = new Size(123, 16);
            label17.TabIndex = 10;
            label17.Text = "Intervalo de Pedido";
            // 
            // txtEstoqueMedio
            // 
            txtEstoqueMedio.Location = new Point(108, 40);
            txtEstoqueMedio.Name = "txtEstoqueMedio";
            txtEstoqueMedio.Size = new Size(128, 22);
            txtEstoqueMedio.TabIndex = 4;
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.ForeColor = Color.FromArgb(21, 48, 65);
            label18.Location = new Point(9, 43);
            label18.Name = "label18";
            label18.Size = new Size(93, 16);
            label18.TabIndex = 8;
            label18.Text = "Estoque Medio";
            // 
            // txtEstoqueMaximo
            // 
            txtEstoqueMaximo.Location = new Point(366, 12);
            txtEstoqueMaximo.Name = "txtEstoqueMaximo";
            txtEstoqueMaximo.Size = new Size(111, 22);
            txtEstoqueMaximo.TabIndex = 3;
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.ForeColor = Color.FromArgb(21, 48, 65);
            label19.Location = new Point(261, 12);
            label19.Name = "label19";
            label19.Size = new Size(103, 16);
            label19.TabIndex = 6;
            label19.Text = "Estoque Maximo";
            // 
            // txtEstoqueSeguranca
            // 
            txtEstoqueSeguranca.Location = new Point(151, 12);
            txtEstoqueSeguranca.Name = "txtEstoqueSeguranca";
            txtEstoqueSeguranca.Size = new Size(104, 22);
            txtEstoqueSeguranca.TabIndex = 2;
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.ForeColor = Color.FromArgb(21, 48, 65);
            label20.Location = new Point(7, 12);
            label20.Name = "label20";
            label20.Size = new Size(138, 16);
            label20.TabIndex = 4;
            label20.Text = "Estoque de Segurança";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(txtObs);
            groupBox2.Controls.Add(label9);
            groupBox2.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point);
            groupBox2.Location = new Point(6, 272);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(677, 153);
            groupBox2.TabIndex = 24;
            groupBox2.TabStop = false;
            // 
            // txtObs
            // 
            txtObs.Location = new Point(6, 38);
            txtObs.Multiline = true;
            txtObs.Name = "txtObs";
            txtObs.Size = new Size(667, 102);
            txtObs.TabIndex = 9;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label9.ForeColor = Color.FromArgb(21, 48, 65);
            label9.Location = new Point(0, 19);
            label9.Name = "label9";
            label9.Size = new Size(87, 16);
            label9.TabIndex = 16;
            label9.Text = "Observação";
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(btnExportCsv);
            groupBox3.Controls.Add(label10);
            groupBox3.Controls.Add(label21);
            groupBox3.Controls.Add(btnExcluir);
            groupBox3.Controls.Add(btnLimpar);
            groupBox3.Controls.Add(btnPesquisar);
            groupBox3.Controls.Add(btnAlterar);
            groupBox3.Location = new Point(0, 431);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(693, 106);
            groupBox3.TabIndex = 25;
            groupBox3.TabStop = false;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Century Gothic", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label10.Location = new Point(1, 29);
            label10.Name = "label10";
            label10.Size = new Size(445, 17);
            label10.TabIndex = 24;
            label10.Text = "Faça pesquisas, limpe, exclua ou altere os dados do seu formulário.";
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.BackColor = SystemColors.Control;
            label21.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label21.ForeColor = Color.FromArgb(21, 48, 65);
            label21.Location = new Point(1, 10);
            label21.Name = "label21";
            label21.Size = new Size(99, 19);
            label21.TabIndex = 23;
            label21.Text = "Mais ações:";
            // 
            // btnExcluir
            // 
            btnExcluir.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnExcluir.ForeColor = Color.FromArgb(21, 48, 65);
            btnExcluir.Location = new Point(233, 60);
            btnExcluir.Name = "btnExcluir";
            btnExcluir.Size = new Size(68, 30);
            btnExcluir.TabIndex = 4;
            btnExcluir.Text = "Excluir";
            btnExcluir.UseVisualStyleBackColor = true;
            // 
            // btnLimpar
            // 
            btnLimpar.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnLimpar.ForeColor = Color.FromArgb(21, 48, 65);
            btnLimpar.Location = new Point(159, 60);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(68, 30);
            btnLimpar.TabIndex = 3;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            // 
            // btnPesquisar
            // 
            btnPesquisar.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnPesquisar.ForeColor = Color.FromArgb(21, 48, 65);
            btnPesquisar.Location = new Point(79, 60);
            btnPesquisar.Name = "btnPesquisar";
            btnPesquisar.Size = new Size(74, 30);
            btnPesquisar.TabIndex = 2;
            btnPesquisar.Text = "Pesquisar";
            btnPesquisar.UseVisualStyleBackColor = true;
            // 
            // btnAlterar
            // 
            btnAlterar.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnAlterar.ForeColor = Color.FromArgb(21, 48, 65);
            btnAlterar.Location = new Point(6, 60);
            btnAlterar.Name = "btnAlterar";
            btnAlterar.Size = new Size(68, 30);
            btnAlterar.TabIndex = 1;
            btnAlterar.Text = "Alterar";
            btnAlterar.UseVisualStyleBackColor = true;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.RODAPÉ;
            pictureBox2.Location = new Point(3, 543);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(690, 61);
            pictureBox2.TabIndex = 26;
            pictureBox2.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.FromArgb(21, 48, 65);
            label1.Font = new Font("Century Gothic", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.White;
            label1.Location = new Point(186, 20);
            label1.Name = "label1";
            label1.Size = new Size(222, 23);
            label1.TabIndex = 27;
            label1.Text = "Parâmetros de Estoque";
            // 
            // parametroEstoque
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(686, 605);
            Controls.Add(label1);
            Controls.Add(pictureBox2);
            Controls.Add(groupBox3);
            Controls.Add(groupBox2);
            Controls.Add(groupBox4);
            Controls.Add(pictureBox1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "parametroEstoque";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "parametroEstoque";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            groupBox4.ResumeLayout(false);
            groupBox4.PerformLayout();
            groupBox5.ResumeLayout(false);
            groupBox5.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.ComponentModel.BackgroundWorker backgroundWorker2;
        private Button btnExportCsv;
        private PictureBox pictureBox1;
        private GroupBox groupBox4;
        private GroupBox groupBox5;
        private ComboBox cboStatus;
        private Label label8;
        private ComboBox cboIdProduto;
        private ComboBox cbValorProduto;
        private Label label12;
        private TextBox txtId;
        private Label label13;
        private TextBox txtPontoPedido;
        private Label label14;
        private TextBox txtIntervaloTempo;
        private Label label15;
        private Button button1;
        private TextBox txtLec;
        private Label label16;
        private TextBox txtIntervalorPedido;
        private Label label17;
        private TextBox txtEstoqueMedio;
        private Label label18;
        private TextBox txtEstoqueMaximo;
        private Label label19;
        private TextBox txtEstoqueSeguranca;
        private Label label20;
        private GroupBox groupBox2;
        private TextBox txtObs;
        private Label label9;
        private GroupBox groupBox3;
        private Label label10;
        private Label label21;
        private Button btnExcluir;
        private Button btnLimpar;
        private Button btnPesquisar;
        private Button btnAlterar;
        private PictureBox pictureBox2;
        private Label label1;
    }
}