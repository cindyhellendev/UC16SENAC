﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sistema
{
    public partial class mdiPrejeto : Form
    {
        private int childFormNumber = 0;

        public mdiPrejeto()
        {
            InitializeComponent();

        }

        private void fornecedorToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void produtoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void parametroEstoqueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void categoriaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void nivelDeServiçoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void pnForncedor_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void picFornecedor_Click(object sender, EventArgs e)
        {
            
        }

        private void lbFornecedor_Click(object sender, EventArgs e)
        {
            
        }

        private void lbProduto_Click(object sender, EventArgs e)
        {
            
        }

        private void lbParametroEstoque_Click(object sender, EventArgs e)
        {
            
        }

        private void lbCategoria_Click(object sender, EventArgs e)
        {
            
        }

        private void lbNV_Click(object sender, EventArgs e)
        {
           
        }

        private void lbFornecedor_Click_1(object sender, EventArgs e)
        {
            fornecedor frm = new fornecedor();
            frm.MdiParent = this;
            frm.Show();
        }

        private void lbProduto_Click_1(object sender, EventArgs e)
        {
            produto frm = new produto();
            frm.MdiParent = this;
            frm.Show();
        }

        private void lbCat_Click(object sender, EventArgs e)
        {
            frmCategoria frm = new frmCategoria();
            frm.MdiParent = this;
            frm.Show();
        }

        private void lbNV_Click_1(object sender, EventArgs e)
        {
            FrmNiveldeServico frm = new FrmNiveldeServico();
            frm.MdiParent = this;
            frm.Show();
        }

        private void lbParametroEstoque_Click_1(object sender, EventArgs e)
        {
            parametroEstoque frm = new parametroEstoque();
            frm.MdiParent = this;
            frm.Show();
        }

        private void mdiPrejeto_Load(object sender, EventArgs e)
        {
            foreach (Control control in this.Controls)
            {
                if (control is MdiClient)
                {
                    control.BackColor = Color.Black;
                    break;
                }
            }
        }

        private void pnPrejeto_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
