﻿namespace sistema
{
    partial class fornecedor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtObs = new TextBox();
            pictureBox1 = new PictureBox();
            groupBox4 = new GroupBox();
            label13 = new Label();
            groupBox5 = new GroupBox();
            cboStatus = new ComboBox();
            btnSair = new Button();
            label14 = new Label();
            btnExcluir = new Button();
            btnLimpar = new Button();
            btnPesquisar = new Button();
            btnAlterar = new Button();
            btnSalvar = new Button();
            pictureBox2 = new PictureBox();
            mskTell = new MaskedTextBox();
            mskCnpj = new MaskedTextBox();
            txtCodigo = new TextBox();
            label11 = new Label();
            txtInscricaoEstadual = new TextBox();
            txtRazaoSocial = new TextBox();
            label12 = new Label();
            label15 = new Label();
            txtUf = new TextBox();
            txtNome = new TextBox();
            label16 = new Label();
            label17 = new Label();
            txtEndereco = new TextBox();
            label18 = new Label();
            label19 = new Label();
            label20 = new Label();
            label21 = new Label();
            txtTempoAtendimentoSku = new TextBox();
            txtEmail = new TextBox();
            label22 = new Label();
            label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            groupBox4.SuspendLayout();
            groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // txtObs
            // 
            txtObs.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txtObs.Location = new Point(6, 38);
            txtObs.Multiline = true;
            txtObs.Name = "txtObs";
            txtObs.Size = new Size(673, 118);
            txtObs.TabIndex = 10;
            txtObs.TextChanged += txtObs_TextChanged;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.Captura_de_tela_2024_06_02_010232;
            pictureBox1.Location = new Point(1, -1);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(685, 93);
            pictureBox1.TabIndex = 23;
            pictureBox1.TabStop = false;
            // 
            // groupBox4
            // 
            groupBox4.Controls.Add(label13);
            groupBox4.Controls.Add(txtObs);
            groupBox4.Font = new Font("Century Gothic", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            groupBox4.ForeColor = Color.FromArgb(11, 48, 65);
            groupBox4.Location = new Point(1, 246);
            groupBox4.Name = "groupBox4";
            groupBox4.Size = new Size(685, 186);
            groupBox4.TabIndex = 24;
            groupBox4.TabStop = false;
            groupBox4.Enter += groupBox4_Enter;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Century Gothic", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            label13.Location = new Point(6, 17);
            label13.Name = "label13";
            label13.Size = new Size(106, 18);
            label13.TabIndex = 20;
            label13.Text = "Observações";
            // 
            // groupBox5
            // 
            groupBox5.Controls.Add(btnSair);
            groupBox5.Controls.Add(btnExcluir);
            groupBox5.Controls.Add(btnLimpar);
            groupBox5.Controls.Add(btnPesquisar);
            groupBox5.Controls.Add(btnAlterar);
            groupBox5.Controls.Add(btnSalvar);
            groupBox5.Location = new Point(1, 423);
            groupBox5.Name = "groupBox5";
            groupBox5.Size = new Size(685, 72);
            groupBox5.TabIndex = 25;
            groupBox5.TabStop = false;
            // 
            // cboStatus
            // 
            cboStatus.DropDownStyle = ComboBoxStyle.DropDownList;
            cboStatus.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            cboStatus.FormattingEnabled = true;
            cboStatus.Items.AddRange(new object[] { "ATIVO \t", "INATIVO" });
            cboStatus.Location = new Point(593, 194);
            cboStatus.Name = "cboStatus";
            cboStatus.Size = new Size(95, 29);
            cboStatus.TabIndex = 11;
            // 
            // btnSair
            // 
            btnSair.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnSair.ForeColor = Color.FromArgb(11, 48, 65);
            btnSair.Location = new Point(392, 12);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(69, 35);
            btnSair.TabIndex = 5;
            btnSair.Text = "Fechar";
            btnSair.UseVisualStyleBackColor = true;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Century Gothic", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            label14.ForeColor = Color.FromArgb(11, 48, 65);
            label14.Location = new Point(527, 199);
            label14.Name = "label14";
            label14.Size = new Size(49, 18);
            label14.TabIndex = 22;
            label14.Text = "Status";
            // 
            // btnExcluir
            // 
            btnExcluir.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnExcluir.ForeColor = Color.FromArgb(11, 48, 65);
            btnExcluir.Location = new Point(317, 12);
            btnExcluir.Name = "btnExcluir";
            btnExcluir.Size = new Size(69, 35);
            btnExcluir.TabIndex = 4;
            btnExcluir.Text = "Excluir";
            btnExcluir.UseVisualStyleBackColor = true;
            // 
            // btnLimpar
            // 
            btnLimpar.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnLimpar.ForeColor = Color.FromArgb(11, 48, 65);
            btnLimpar.Location = new Point(242, 12);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(69, 35);
            btnLimpar.TabIndex = 3;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            // 
            // btnPesquisar
            // 
            btnPesquisar.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnPesquisar.ForeColor = Color.FromArgb(11, 48, 65);
            btnPesquisar.Location = new Point(159, 12);
            btnPesquisar.Name = "btnPesquisar";
            btnPesquisar.Size = new Size(77, 35);
            btnPesquisar.TabIndex = 2;
            btnPesquisar.Text = "Pesquisar";
            btnPesquisar.UseVisualStyleBackColor = true;
            // 
            // btnAlterar
            // 
            btnAlterar.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnAlterar.ForeColor = Color.FromArgb(11, 48, 65);
            btnAlterar.Location = new Point(84, 12);
            btnAlterar.Name = "btnAlterar";
            btnAlterar.Size = new Size(69, 35);
            btnAlterar.TabIndex = 1;
            btnAlterar.Text = "Alterar";
            btnAlterar.UseVisualStyleBackColor = true;
            // 
            // btnSalvar
            // 
            btnSalvar.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnSalvar.ForeColor = Color.FromArgb(11, 48, 65);
            btnSalvar.Location = new Point(9, 12);
            btnSalvar.Name = "btnSalvar";
            btnSalvar.Size = new Size(69, 35);
            btnSalvar.TabIndex = 0;
            btnSalvar.Text = "Salvar";
            btnSalvar.UseVisualStyleBackColor = true;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.RODAPÉ;
            pictureBox2.Location = new Point(1, 501);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(687, 63);
            pictureBox2.TabIndex = 26;
            pictureBox2.TabStop = false;
            // 
            // mskTell
            // 
            mskTell.BackColor = Color.White;
            mskTell.Font = new Font("Century Gothic", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            mskTell.ForeColor = Color.FromArgb(11, 48, 65);
            mskTell.Location = new Point(70, 127);
            mskTell.Mask = "###########";
            mskTell.Name = "mskTell";
            mskTell.Size = new Size(151, 26);
            mskTell.TabIndex = 33;
            // 
            // mskCnpj
            // 
            mskCnpj.BackColor = Color.White;
            mskCnpj.Font = new Font("Century Gothic", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            mskCnpj.ForeColor = Color.FromArgb(11, 48, 65);
            mskCnpj.Location = new Point(57, 186);
            mskCnpj.Mask = "##############";
            mskCnpj.Name = "mskCnpj";
            mskCnpj.Size = new Size(125, 26);
            mskCnpj.TabIndex = 37;
            // 
            // txtCodigo
            // 
            txtCodigo.BackColor = Color.White;
            txtCodigo.Font = new Font("Century Gothic", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            txtCodigo.ForeColor = Color.FromArgb(11, 48, 65);
            txtCodigo.Location = new Point(640, 98);
            txtCodigo.Name = "txtCodigo";
            txtCodigo.Size = new Size(46, 26);
            txtCodigo.TabIndex = 31;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Century Gothic", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            label11.ForeColor = Color.FromArgb(11, 48, 65);
            label11.Location = new Point(621, 101);
            label11.Name = "label11";
            label11.Size = new Size(23, 18);
            label11.TabIndex = 46;
            label11.Text = "ID";
            // 
            // txtInscricaoEstadual
            // 
            txtInscricaoEstadual.BackColor = Color.White;
            txtInscricaoEstadual.Font = new Font("Century Gothic", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            txtInscricaoEstadual.ForeColor = Color.FromArgb(11, 48, 65);
            txtInscricaoEstadual.Location = new Point(527, 162);
            txtInscricaoEstadual.Name = "txtInscricaoEstadual";
            txtInscricaoEstadual.Size = new Size(161, 26);
            txtInscricaoEstadual.TabIndex = 45;
            // 
            // txtRazaoSocial
            // 
            txtRazaoSocial.BackColor = Color.White;
            txtRazaoSocial.Font = new Font("Century Gothic", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            txtRazaoSocial.ForeColor = Color.FromArgb(11, 48, 65);
            txtRazaoSocial.Location = new Point(104, 157);
            txtRazaoSocial.Name = "txtRazaoSocial";
            txtRazaoSocial.Size = new Size(278, 26);
            txtRazaoSocial.TabIndex = 36;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Century Gothic", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            label12.ForeColor = Color.FromArgb(11, 48, 65);
            label12.Location = new Point(388, 162);
            label12.Name = "label12";
            label12.Size = new Size(141, 18);
            label12.TabIndex = 44;
            label12.Text = "Inscrição Estadual";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Century Gothic", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            label15.ForeColor = Color.FromArgb(11, 48, 65);
            label15.Location = new Point(3, 98);
            label15.Name = "label15";
            label15.Size = new Size(53, 18);
            label15.TabIndex = 27;
            label15.Text = "Nome";
            label15.TextAlign = ContentAlignment.TopCenter;
            // 
            // txtUf
            // 
            txtUf.BackColor = Color.White;
            txtUf.Font = new Font("Century Gothic", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            txtUf.ForeColor = Color.FromArgb(11, 48, 65);
            txtUf.Location = new Point(217, 183);
            txtUf.Name = "txtUf";
            txtUf.Size = new Size(40, 26);
            txtUf.TabIndex = 39;
            // 
            // txtNome
            // 
            txtNome.BackColor = Color.White;
            txtNome.Font = new Font("Century Gothic", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            txtNome.ForeColor = Color.FromArgb(11, 48, 65);
            txtNome.Location = new Point(57, 98);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(291, 26);
            txtNome.TabIndex = 28;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Century Gothic", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            label16.ForeColor = Color.FromArgb(11, 48, 65);
            label16.Location = new Point(186, 186);
            label16.Name = "label16";
            label16.Size = new Size(25, 18);
            label16.TabIndex = 43;
            label16.Text = "UF";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Font = new Font("Century Gothic", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            label17.ForeColor = Color.FromArgb(11, 48, 65);
            label17.Location = new Point(354, 101);
            label17.Name = "label17";
            label17.Size = new Size(80, 18);
            label17.TabIndex = 30;
            label17.Text = "Endereço";
            label17.TextAlign = ContentAlignment.TopCenter;
            // 
            // txtEndereco
            // 
            txtEndereco.BackColor = Color.White;
            txtEndereco.Font = new Font("Century Gothic", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            txtEndereco.ForeColor = Color.FromArgb(11, 48, 65);
            txtEndereco.Location = new Point(440, 98);
            txtEndereco.Name = "txtEndereco";
            txtEndereco.Size = new Size(177, 26);
            txtEndereco.TabIndex = 29;
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Font = new Font("Century Gothic", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            label18.ForeColor = Color.FromArgb(11, 48, 65);
            label18.Location = new Point(3, 156);
            label18.Name = "label18";
            label18.Size = new Size(104, 18);
            label18.TabIndex = 42;
            label18.Text = "Razão Social";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Font = new Font("Century Gothic", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            label19.ForeColor = Color.FromArgb(11, 48, 65);
            label19.Location = new Point(3, 130);
            label19.Name = "label19";
            label19.Size = new Size(71, 18);
            label19.TabIndex = 32;
            label19.Text = "Telefone";
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Font = new Font("Century Gothic", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            label20.ForeColor = Color.FromArgb(11, 48, 65);
            label20.Location = new Point(5, 189);
            label20.Name = "label20";
            label20.Size = new Size(46, 18);
            label20.TabIndex = 41;
            label20.Text = "CNPJ";
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Font = new Font("Century Gothic", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            label21.ForeColor = Color.FromArgb(11, 48, 65);
            label21.Location = new Point(227, 136);
            label21.Name = "label21";
            label21.Size = new Size(54, 18);
            label21.TabIndex = 38;
            label21.Text = "E-mail";
            // 
            // txtTempoAtendimentoSku
            // 
            txtTempoAtendimentoSku.BackColor = Color.White;
            txtTempoAtendimentoSku.Font = new Font("Century Gothic", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            txtTempoAtendimentoSku.ForeColor = Color.FromArgb(11, 48, 65);
            txtTempoAtendimentoSku.Location = new Point(604, 130);
            txtTempoAtendimentoSku.Name = "txtTempoAtendimentoSku";
            txtTempoAtendimentoSku.Size = new Size(82, 26);
            txtTempoAtendimentoSku.TabIndex = 35;
            // 
            // txtEmail
            // 
            txtEmail.BackColor = Color.White;
            txtEmail.Font = new Font("Century Gothic", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            txtEmail.ForeColor = Color.FromArgb(11, 48, 65);
            txtEmail.Location = new Point(283, 130);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(89, 26);
            txtEmail.TabIndex = 34;
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.Font = new Font("Century Gothic", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            label22.ForeColor = Color.FromArgb(11, 48, 65);
            label22.Location = new Point(378, 135);
            label22.Name = "label22";
            label22.Size = new Size(223, 18);
            label22.TabIndex = 40;
            label22.Text = "Tempo de atendimento (SKU)";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.FromArgb(11, 48, 65);
            label1.Font = new Font("Century Gothic", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.White;
            label1.Location = new Point(227, 20);
            label1.Name = "label1";
            label1.Size = new Size(135, 23);
            label1.TabIndex = 22;
            label1.Text = "Fornecedores";
            // 
            // fornecedor
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(687, 564);
            Controls.Add(label1);
            Controls.Add(cboStatus);
            Controls.Add(label14);
            Controls.Add(mskTell);
            Controls.Add(mskCnpj);
            Controls.Add(txtCodigo);
            Controls.Add(label11);
            Controls.Add(txtInscricaoEstadual);
            Controls.Add(txtRazaoSocial);
            Controls.Add(label12);
            Controls.Add(label15);
            Controls.Add(txtUf);
            Controls.Add(txtNome);
            Controls.Add(label16);
            Controls.Add(label17);
            Controls.Add(txtEndereco);
            Controls.Add(label18);
            Controls.Add(label19);
            Controls.Add(label20);
            Controls.Add(label21);
            Controls.Add(txtTempoAtendimentoSku);
            Controls.Add(txtEmail);
            Controls.Add(label22);
            Controls.Add(pictureBox2);
            Controls.Add(groupBox5);
            Controls.Add(groupBox4);
            Controls.Add(pictureBox1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "fornecedor";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "fornecedor";
            Load += fornecedor_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            groupBox4.ResumeLayout(false);
            groupBox4.PerformLayout();
            groupBox5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private TextBox txtObs;
        private PictureBox pictureBox1;
        private GroupBox groupBox4;
        private Label label13;
        private GroupBox groupBox5;
        private ComboBox cboStatus;
        private Button btnSair;
        private Label label14;
        private Button btnExcluir;
        private Button btnLimpar;
        private Button btnPesquisar;
        private Button btnAlterar;
        private Button btnSalvar;
        private PictureBox pictureBox2;
        private MaskedTextBox mskTell;
        private MaskedTextBox mskCnpj;
        private TextBox txtCodigo;
        private Label label11;
        private TextBox txtInscricaoEstadual;
        private TextBox txtRazaoSocial;
        private Label label12;
        private Label label15;
        private TextBox txtUf;
        private TextBox txtNome;
        private Label label16;
        private Label label17;
        private TextBox txtEndereco;
        private Label label18;
        private Label label19;
        private Label label20;
        private Label label21;
        private TextBox txtTempoAtendimentoSku;
        private TextBox txtEmail;
        private Label label22;
        private Label label1;
    }
}