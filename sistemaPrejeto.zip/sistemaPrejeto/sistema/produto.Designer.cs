﻿namespace sistema
{
    partial class produto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnGerarUmPdf = new Button();
            btnGerarPdf = new Button();
            btnParametros = new Button();
            btnImportar = new Button();
            btnExportarDados = new Button();
            btnFechar = new Button();
            pictureBox1 = new PictureBox();
            groupBox4 = new GroupBox();
            label17 = new Label();
            cbValorNV = new ComboBox();
            cboStatus = new ComboBox();
            cbValorFornecedor = new ComboBox();
            txtObs = new TextBox();
            label18 = new Label();
            button1 = new Button();
            txtCodigo = new TextBox();
            label19 = new Label();
            txtDescricao = new TextBox();
            label20 = new Label();
            cboValorCat = new ComboBox();
            txtPcArmazenagem = new TextBox();
            label21 = new Label();
            label22 = new Label();
            txtCa = new TextBox();
            cboIdNivelServico = new ComboBox();
            label23 = new Label();
            label24 = new Label();
            txtPcAquisicao = new TextBox();
            cboIdFornecedor = new ComboBox();
            label25 = new Label();
            txtCustoAquisicao = new TextBox();
            label26 = new Label();
            txtCustoPedido = new TextBox();
            label27 = new Label();
            txtNome = new TextBox();
            label28 = new Label();
            label29 = new Label();
            cboIdCategoria = new ComboBox();
            groupBox5 = new GroupBox();
            label30 = new Label();
            label31 = new Label();
            btnExcluir = new Button();
            btnLimpar = new Button();
            btnPesquisar = new Button();
            btnAlterar = new Button();
            pictureBox2 = new PictureBox();
            label14 = new Label();
            txtCodbarras = new TextBox();
            label1 = new Label();
            txtDescricao2 = new TextBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            groupBox4.SuspendLayout();
            groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // btnGerarUmPdf
            // 
            btnGerarUmPdf.Location = new Point(317, 50);
            btnGerarUmPdf.Name = "btnGerarUmPdf";
            btnGerarUmPdf.Size = new Size(121, 35);
            btnGerarUmPdf.TabIndex = 31;
            btnGerarUmPdf.Text = "Gerar um PDF";
            btnGerarUmPdf.UseVisualStyleBackColor = true;
            btnGerarUmPdf.Click += btnGerarUmPdf_Click;
            // 
            // btnGerarPdf
            // 
            btnGerarPdf.Location = new Point(444, 49);
            btnGerarPdf.Name = "btnGerarPdf";
            btnGerarPdf.Size = new Size(99, 36);
            btnGerarPdf.TabIndex = 30;
            btnGerarPdf.Text = "Gerar PDF";
            btnGerarPdf.UseVisualStyleBackColor = true;
            btnGerarPdf.Click += btnGerarPdf_Click;
            // 
            // btnParametros
            // 
            btnParametros.Location = new Point(549, 47);
            btnParametros.Name = "btnParametros";
            btnParametros.Size = new Size(96, 36);
            btnParametros.TabIndex = 29;
            btnParametros.Text = "Parametros";
            btnParametros.UseVisualStyleBackColor = true;
            btnParametros.Click += button2_Click;
            // 
            // btnImportar
            // 
            btnImportar.Location = new Point(9, 97);
            btnImportar.Name = "btnImportar";
            btnImportar.Size = new Size(69, 26);
            btnImportar.TabIndex = 22;
            btnImportar.Text = "Importar";
            btnImportar.UseVisualStyleBackColor = true;
            btnImportar.Click += button1_Click;
            // 
            // btnExportarDados
            // 
            btnExportarDados.Location = new Point(84, 95);
            btnExportarDados.Name = "btnExportarDados";
            btnExportarDados.Size = new Size(96, 28);
            btnExportarDados.TabIndex = 22;
            btnExportarDados.Text = "Exportar Dados";
            btnExportarDados.UseVisualStyleBackColor = true;
            btnExportarDados.Click += btnExportarDados_Click;
            // 
            // btnFechar
            // 
            btnFechar.FlatStyle = FlatStyle.Popup;
            btnFechar.Image = Properties.Resources.sair;
            btnFechar.Location = new Point(625, 29);
            btnFechar.Name = "btnFechar";
            btnFechar.Size = new Size(39, 37);
            btnFechar.TabIndex = 5;
            btnFechar.UseVisualStyleBackColor = true;
            btnFechar.Click += btnFechar_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.Transparent;
            pictureBox1.Image = Properties.Resources.Captura_de_tela_2024_06_02_010232;
            pictureBox1.Location = new Point(3, 1);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(687, 94);
            pictureBox1.TabIndex = 4;
            pictureBox1.TabStop = false;
            // 
            // groupBox4
            // 
            groupBox4.Controls.Add(txtDescricao2);
            groupBox4.Controls.Add(label1);
            groupBox4.Controls.Add(txtCodbarras);
            groupBox4.Controls.Add(label17);
            groupBox4.Controls.Add(cbValorNV);
            groupBox4.Controls.Add(cboStatus);
            groupBox4.Controls.Add(cbValorFornecedor);
            groupBox4.Controls.Add(txtObs);
            groupBox4.Controls.Add(label18);
            groupBox4.Controls.Add(button1);
            groupBox4.Controls.Add(txtCodigo);
            groupBox4.Controls.Add(label19);
            groupBox4.Controls.Add(txtDescricao);
            groupBox4.Controls.Add(label20);
            groupBox4.Controls.Add(cboValorCat);
            groupBox4.Controls.Add(txtPcArmazenagem);
            groupBox4.Controls.Add(label21);
            groupBox4.Controls.Add(label22);
            groupBox4.Controls.Add(txtCa);
            groupBox4.Controls.Add(cboIdNivelServico);
            groupBox4.Controls.Add(label23);
            groupBox4.Controls.Add(label24);
            groupBox4.Controls.Add(txtPcAquisicao);
            groupBox4.Controls.Add(cboIdFornecedor);
            groupBox4.Controls.Add(label25);
            groupBox4.Controls.Add(txtCustoAquisicao);
            groupBox4.Controls.Add(label26);
            groupBox4.Controls.Add(txtCustoPedido);
            groupBox4.Controls.Add(label27);
            groupBox4.Controls.Add(txtNome);
            groupBox4.Controls.Add(label28);
            groupBox4.Controls.Add(label29);
            groupBox4.Controls.Add(cboIdCategoria);
            groupBox4.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
            groupBox4.ForeColor = Color.FromArgb(21, 48, 65);
            groupBox4.Location = new Point(3, 91);
            groupBox4.Name = "groupBox4";
            groupBox4.Size = new Size(687, 380);
            groupBox4.TabIndex = 5;
            groupBox4.TabStop = false;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label17.Location = new Point(590, 162);
            label17.Name = "label17";
            label17.Size = new Size(45, 16);
            label17.TabIndex = 18;
            label17.Text = "Status";
            // 
            // cbValorNV
            // 
            cbValorNV.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            cbValorNV.FormattingEnabled = true;
            cbValorNV.Location = new Point(590, 132);
            cbValorNV.Name = "cbValorNV";
            cbValorNV.Size = new Size(92, 24);
            cbValorNV.TabIndex = 20;
            cbValorNV.Visible = false;
            // 
            // cboStatus
            // 
            cboStatus.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            cboStatus.FormattingEnabled = true;
            cboStatus.Items.AddRange(new object[] { "ATIVO\t", "INATIVO" });
            cboStatus.Location = new Point(590, 185);
            cboStatus.Name = "cboStatus";
            cboStatus.Size = new Size(86, 24);
            cboStatus.TabIndex = 10;
            // 
            // cbValorFornecedor
            // 
            cbValorFornecedor.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            cbValorFornecedor.FormattingEnabled = true;
            cbValorFornecedor.Location = new Point(596, 39);
            cbValorFornecedor.Name = "cbValorFornecedor";
            cbValorFornecedor.Size = new Size(86, 24);
            cbValorFornecedor.TabIndex = 21;
            cbValorFornecedor.Visible = false;
            // 
            // txtObs
            // 
            txtObs.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            txtObs.Location = new Point(355, 185);
            txtObs.Multiline = true;
            txtObs.Name = "txtObs";
            txtObs.Size = new Size(229, 93);
            txtObs.TabIndex = 11;
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label18.Location = new Point(355, 166);
            label18.Name = "label18";
            label18.Size = new Size(92, 16);
            label18.TabIndex = 15;
            label18.Text = "Observações";
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(21, 48, 65);
            button1.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point);
            button1.ForeColor = Color.White;
            button1.Location = new Point(616, 245);
            button1.Name = "button1";
            button1.Size = new Size(60, 33);
            button1.TabIndex = 0;
            button1.Text = "Salvar";
            button1.UseVisualStyleBackColor = false;
            // 
            // txtCodigo
            // 
            txtCodigo.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            txtCodigo.Location = new Point(648, 13);
            txtCodigo.Name = "txtCodigo";
            txtCodigo.Size = new Size(34, 23);
            txtCodigo.TabIndex = 13;
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label19.Location = new Point(622, 16);
            label19.Name = "label19";
            label19.Size = new Size(20, 16);
            label19.TabIndex = 12;
            label19.Text = "ID";
            // 
            // txtDescricao
            // 
            txtDescricao.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            txtDescricao.Location = new Point(6, 185);
            txtDescricao.Multiline = true;
            txtDescricao.Name = "txtDescricao";
            txtDescricao.Size = new Size(341, 93);
            txtDescricao.TabIndex = 11;
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label20.Location = new Point(6, 166);
            label20.Name = "label20";
            label20.Size = new Size(152, 16);
            label20.TabIndex = 10;
            label20.Text = "Descrição do produto:";
            // 
            // cboValorCat
            // 
            cboValorCat.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            cboValorCat.FormattingEnabled = true;
            cboValorCat.Location = new Point(255, 39);
            cboValorCat.Name = "cboValorCat";
            cboValorCat.Size = new Size(92, 24);
            cboValorCat.TabIndex = 19;
            cboValorCat.Visible = false;
            // 
            // txtPcArmazenagem
            // 
            txtPcArmazenagem.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            txtPcArmazenagem.Location = new Point(269, 132);
            txtPcArmazenagem.Name = "txtPcArmazenagem";
            txtPcArmazenagem.Size = new Size(78, 23);
            txtPcArmazenagem.TabIndex = 6;
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label21.Location = new Point(6, 135);
            label21.Name = "label21";
            label21.Size = new Size(258, 16);
            label21.TabIndex = 10;
            label21.Text = "Percentual de Custo de Armazenagem";
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label22.Location = new Point(355, 135);
            label22.Name = "label22";
            label22.Size = new Size(112, 16);
            label22.TabIndex = 12;
            label22.Text = "Nivel de Serviço";
            // 
            // txtCa
            // 
            txtCa.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            txtCa.Location = new Point(523, 98);
            txtCa.Name = "txtCa";
            txtCa.Size = new Size(159, 23);
            txtCa.TabIndex = 5;
            // 
            // cboIdNivelServico
            // 
            cboIdNivelServico.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            cboIdNivelServico.FormattingEnabled = true;
            cboIdNivelServico.Location = new Point(473, 131);
            cboIdNivelServico.Name = "cboIdNivelServico";
            cboIdNivelServico.Size = new Size(111, 24);
            cboIdNivelServico.TabIndex = 8;
            cboIdNivelServico.TabStop = false;
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label23.Location = new Point(353, 103);
            label23.Name = "label23";
            label23.Size = new Size(164, 16);
            label23.TabIndex = 8;
            label23.Text = "Custo de Armazenagem";
            // 
            // label24
            // 
            label24.AutoSize = true;
            label24.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label24.Location = new Point(353, 42);
            label24.Name = "label24";
            label24.Size = new Size(80, 16);
            label24.TabIndex = 14;
            label24.Text = "Fornecedor";
            // 
            // txtPcAquisicao
            // 
            txtPcAquisicao.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            txtPcAquisicao.Location = new Point(240, 100);
            txtPcAquisicao.Name = "txtPcAquisicao";
            txtPcAquisicao.Size = new Size(107, 23);
            txtPcAquisicao.TabIndex = 4;
            // 
            // cboIdFornecedor
            // 
            cboIdFornecedor.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            cboIdFornecedor.FormattingEnabled = true;
            cboIdFornecedor.Location = new Point(439, 39);
            cboIdFornecedor.Name = "cboIdFornecedor";
            cboIdFornecedor.Size = new Size(151, 24);
            cboIdFornecedor.TabIndex = 9;
            // 
            // label25
            // 
            label25.AutoSize = true;
            label25.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label25.Location = new Point(6, 107);
            label25.Name = "label25";
            label25.Size = new Size(228, 16);
            label25.TabIndex = 6;
            label25.Text = "Percentual de Custo de Aquisição";
            // 
            // txtCustoAquisicao
            // 
            txtCustoAquisicao.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            txtCustoAquisicao.Location = new Point(568, 69);
            txtCustoAquisicao.Name = "txtCustoAquisicao";
            txtCustoAquisicao.Size = new Size(114, 23);
            txtCustoAquisicao.TabIndex = 3;
            // 
            // label26
            // 
            label26.AutoSize = true;
            label26.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label26.Location = new Point(353, 72);
            label26.Name = "label26";
            label26.Size = new Size(209, 16);
            label26.TabIndex = 4;
            label26.Text = "Custo de aquisição do produto";
            // 
            // txtCustoPedido
            // 
            txtCustoPedido.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            txtCustoPedido.Location = new Point(199, 69);
            txtCustoPedido.Name = "txtCustoPedido";
            txtCustoPedido.Size = new Size(148, 23);
            txtCustoPedido.TabIndex = 2;
            // 
            // label27
            // 
            label27.AutoSize = true;
            label27.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label27.Location = new Point(6, 72);
            label27.Name = "label27";
            label27.Size = new Size(191, 16);
            label27.TabIndex = 2;
            label27.Text = "Custo de pedido do produto";
            // 
            // txtNome
            // 
            txtNome.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            txtNome.Location = new Point(133, 10);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(484, 23);
            txtNome.TabIndex = 1;
            // 
            // label28
            // 
            label28.AutoSize = true;
            label28.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label28.Location = new Point(4, 47);
            label28.Name = "label28";
            label28.Size = new Size(149, 16);
            label28.TabIndex = 10;
            label28.Text = "Categoria do produto";
            // 
            // label29
            // 
            label29.AutoSize = true;
            label29.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label29.Location = new Point(6, 13);
            label29.Name = "label29";
            label29.Size = new Size(121, 16);
            label29.TabIndex = 0;
            label29.Text = "Nome do produto";
            // 
            // cboIdCategoria
            // 
            cboIdCategoria.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            cboIdCategoria.FormattingEnabled = true;
            cboIdCategoria.Location = new Point(159, 39);
            cboIdCategoria.Name = "cboIdCategoria";
            cboIdCategoria.Size = new Size(90, 24);
            cboIdCategoria.TabIndex = 7;
            // 
            // groupBox5
            // 
            groupBox5.Controls.Add(btnParametros);
            groupBox5.Controls.Add(btnGerarPdf);
            groupBox5.Controls.Add(btnGerarUmPdf);
            groupBox5.Controls.Add(label30);
            groupBox5.Controls.Add(label31);
            groupBox5.Controls.Add(btnExcluir);
            groupBox5.Controls.Add(btnExportarDados);
            groupBox5.Controls.Add(btnImportar);
            groupBox5.Controls.Add(btnLimpar);
            groupBox5.Controls.Add(btnPesquisar);
            groupBox5.Controls.Add(btnAlterar);
            groupBox5.Location = new Point(3, 459);
            groupBox5.Name = "groupBox5";
            groupBox5.Size = new Size(687, 134);
            groupBox5.TabIndex = 6;
            groupBox5.TabStop = false;
            groupBox5.Text = ";";
            // 
            // label30
            // 
            label30.AutoSize = true;
            label30.Font = new Font("Century Gothic", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label30.Location = new Point(6, 34);
            label30.Name = "label30";
            label30.Size = new Size(445, 17);
            label30.TabIndex = 26;
            label30.Text = "Faça pesquisas, limpe, exclua ou altere os dados do seu formulário.";
            // 
            // label31
            // 
            label31.AutoSize = true;
            label31.BackColor = SystemColors.Control;
            label31.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label31.ForeColor = Color.FromArgb(21, 48, 65);
            label31.Location = new Point(6, 15);
            label31.Name = "label31";
            label31.Size = new Size(99, 19);
            label31.TabIndex = 25;
            label31.Text = "Mais ações:";
            // 
            // btnExcluir
            // 
            btnExcluir.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnExcluir.ForeColor = Color.FromArgb(21, 48, 65);
            btnExcluir.Location = new Point(242, 54);
            btnExcluir.Name = "btnExcluir";
            btnExcluir.Size = new Size(69, 29);
            btnExcluir.TabIndex = 4;
            btnExcluir.Text = "Excluir";
            btnExcluir.UseVisualStyleBackColor = true;
            // 
            // btnLimpar
            // 
            btnLimpar.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnLimpar.ForeColor = Color.FromArgb(21, 48, 65);
            btnLimpar.Location = new Point(167, 54);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(69, 29);
            btnLimpar.TabIndex = 3;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            // 
            // btnPesquisar
            // 
            btnPesquisar.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnPesquisar.ForeColor = Color.FromArgb(21, 48, 65);
            btnPesquisar.Location = new Point(84, 54);
            btnPesquisar.Name = "btnPesquisar";
            btnPesquisar.Size = new Size(77, 29);
            btnPesquisar.TabIndex = 2;
            btnPesquisar.Text = "Pesquisar";
            btnPesquisar.UseVisualStyleBackColor = true;
            // 
            // btnAlterar
            // 
            btnAlterar.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnAlterar.ForeColor = Color.FromArgb(21, 48, 65);
            btnAlterar.Location = new Point(9, 54);
            btnAlterar.Name = "btnAlterar";
            btnAlterar.Size = new Size(69, 29);
            btnAlterar.TabIndex = 1;
            btnAlterar.Text = "Alterar";
            btnAlterar.UseVisualStyleBackColor = true;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.RODAPÉ;
            pictureBox2.Location = new Point(3, 599);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(687, 63);
            pictureBox2.TabIndex = 7;
            pictureBox2.TabStop = false;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.BackColor = Color.FromArgb(21, 48, 65);
            label14.Font = new Font("Century Gothic", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            label14.ForeColor = Color.White;
            label14.Location = new Point(258, 20);
            label14.Name = "label14";
            label14.Size = new Size(89, 23);
            label14.TabIndex = 33;
            label14.Text = "Produtos";
            // 
            // txtCodbarras
            // 
            txtCodbarras.Location = new Point(9, 315);
            txtCodbarras.Name = "txtCodbarras";
            txtCodbarras.Size = new Size(335, 29);
            txtCodbarras.TabIndex = 22;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(6, 296);
            label1.Name = "label1";
            label1.Size = new Size(123, 16);
            label1.TabIndex = 23;
            label1.Text = "Código de barras";
            // 
            // txtDescricao2
            // 
            txtDescricao2.Font = new Font("Century Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            txtDescricao2.Location = new Point(420, 301);
            txtDescricao2.Multiline = true;
            txtDescricao2.Name = "txtDescricao2";
            txtDescricao2.Size = new Size(262, 43);
            txtDescricao2.TabIndex = 24;
            // 
            // produto
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(691, 663);
            Controls.Add(label14);
            Controls.Add(pictureBox2);
            Controls.Add(btnFechar);
            Controls.Add(groupBox5);
            Controls.Add(groupBox4);
            Controls.Add(pictureBox1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "produto";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "produto";
            Load += produto_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            groupBox4.ResumeLayout(false);
            groupBox4.PerformLayout();
            groupBox5.ResumeLayout(false);
            groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button btnFechar;
        private Button btnExportarDados;
        private Button btnImportar;
        private Button btnParametros;
        private Button btnGerarPdf;
        private Button btnGerarUmPdf;
        private PictureBox pictureBox1;
        private GroupBox groupBox4;
        private Label label17;
        private ComboBox cbValorNV;
        private ComboBox cboStatus;
        private ComboBox cbValorFornecedor;
        private TextBox txtObs;
        private Label label18;
        private Button button1;
        private TextBox txtCodigo;
        private Label label19;
        private TextBox txtDescricao;
        private Label label20;
        private ComboBox cboValorCat;
        private TextBox txtPcArmazenagem;
        private Label label21;
        private Label label22;
        private TextBox txtCa;
        private ComboBox cboIdNivelServico;
        private Label label23;
        private Label label24;
        private TextBox txtPcAquisicao;
        private ComboBox cboIdFornecedor;
        private Label label25;
        private TextBox txtCustoAquisicao;
        private Label label26;
        private TextBox txtCustoPedido;
        private Label label27;
        private TextBox txtNome;
        private Label label28;
        private Label label29;
        private ComboBox cboIdCategoria;
        private GroupBox groupBox5;
        private Label label30;
        private Label label31;
        private Button btnExcluir;
        private Button btnLimpar;
        private Button btnPesquisar;
        private Button btnAlterar;
        private PictureBox pictureBox2;
        private Label label14;
        private Label label1;
        private TextBox txtCodbarras;
        private TextBox txtDescricao2;
    }
}