﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Data;
using System.Data.SqlClient;
using iTextSharp.text;
using iTextSharp.text.pdf;

namespace sistema
{
    public partial class produto : Form
    {
        public produto()
        {
            InitializeComponent();
        }

        string strConexao = "" +
               "Data Source=localhost;" +
               "Initial Catalog=sistema;" +
               "User ID=sa;" +
               "Password=123456";


        private void conexao()
        {
            SqlConnection conn = new SqlConnection(strConexao);

            try
            {
                conn.Open();
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro " + ex.ToString());
                Application.Exit();
            }
        }
        //private void txtDescricao_TextChanged(object sender, EventArgs e)
        private void textBox6_TextChanged(object sender, EventArgs e)
        //private void txtDescricao_TextChanged(object sender, EventArgs e)
        {

        }




        //private void txtPcAquisicao_TextChanged(object sender, EventArgs e)
        private void txPcAquisicao_TextChanged(object sender, EventArgs e)
        //private void txtPcAquisicao_TextChanged(object sender, EventArgs e)
        {

        }





        private void cboIdCategoria_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        void CarregarComboCAT()
        {
            string sql = "select id_categoria, nome_categoria from categoria";

            SqlConnection conexao = new SqlConnection(strConexao);
            SqlCommand cmd = new SqlCommand(sql, conexao);
            cmd.CommandType = CommandType.Text;
            SqlDataReader reader;

            DataTable tabela = new DataTable();

            conexao.Open();




            try
            {
                reader = cmd.ExecuteReader();

                tabela.Load(reader);

                cboValorCat.DisplayMember = "id_categoria";
                cboValorCat.DataSource = tabela;

                cboIdCategoria.DisplayMember = "nome_categoria";
                cboIdCategoria.DataSource = tabela;


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                Application.Exit();

            }
            finally
            {
                conexao.Close();
            }
        }


        private void cboIdNivelServico_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        void CarregarComboNV()
        {
            string sql = "select id_nivel_servico, percentual_nivel_servico from nivel_de_servico";

            SqlConnection conexao = new SqlConnection(strConexao);
            SqlCommand cmd = new SqlCommand(sql, conexao);
            cmd.CommandType = CommandType.Text;
            SqlDataReader reader;

            DataTable tabela = new DataTable();

            conexao.Open();

            try
            {
                reader = cmd.ExecuteReader();

                tabela.Load(reader);

                cbValorNV.DisplayMember = "id_nivel_servico";
                cbValorNV.DataSource = tabela;

                cboIdNivelServico.DisplayMember = "percentual_nivel_servico";
                cboIdNivelServico.DataSource = tabela;


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                Application.Exit();

            }
            finally
            {
                conexao.Close();
            }
        }

        private void cboIdFornecedor_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        void CarregarCombo()
        {
            string sql = "select id_fornecedor, nome_fornecedor from fornecedor";

            SqlConnection conexao = new SqlConnection(strConexao);
            SqlCommand cmd = new SqlCommand(sql, conexao);
            cmd.CommandType = CommandType.Text;
            SqlDataReader reader;

            DataTable tabela = new DataTable();

            conexao.Open();

            try
            {
                reader = cmd.ExecuteReader();

                tabela.Load(reader);
                cboIdFornecedor.DisplayMember = "nome_fornecedor";
                cboIdFornecedor.DataSource = tabela;

                cbValorFornecedor.DisplayMember = "id_fornecedor";
                cbValorFornecedor.DataSource = tabela;


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                Application.Exit();

            }
            finally
            {
                conexao.Close();
            }
        }





        private void cboStatus_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            if (ValidarDados() == false)
            {
                return;
            }

            string sql = "insert into produto" +
                "(" +
                    "nome_produto," +
                    "descricao_produto," +
                    "custo_de_pedido_produto," +
                    "custo_de_aquisicao_produto," +
                    "percentual_de_custo_de_aquisicao_produto," +
                    "custo_de_armazenagem_produto," +
                    "percentual_de_custo_de_armazenagem_produto," +
                    "obs_produto," +
                    "status_produto," +
                    "id_categoria, " +
                    "id_nivel_servico, " +
                    "id_fornecedor, " +
                    "codigo_produto, " +
                    "descricao2_produto, " +
                    "codigoBarras_produto, " +

                ")" +
                "values" +
                "(" +
                    "'" + txtNome.Text + "'," +
                    "'" + txtDescricao.Text + "'," +
                    "'" + txtCustoPedido.Text + "'," +
                    "'" + txtCustoAquisicao.Text + "'," +
                    "'" + txtPcAquisicao.Text + "'," +
                    "'" + txtCa.Text + "'," +
                    "'" + txtPcArmazenagem.Text + "'," +
                    "'" + txtObs.Text + "'," +
                    "'" + cboStatus.Text + "'," +
                    "'" + cboValorCat.Text + "'," +
                    "'" + cbValorNV.Text + "', " +
                    "'" + cbValorFornecedor.Text + "', " +
                    "'" + txtCodigo.Text + "', " +
                    "'" + txtDescricao2.Text + "', " +
                    "'" + txtCodbarras.Text + "' " +

                ")select SCOPE_IDENTITY()";

            SqlConnection conexao = new SqlConnection(strConexao);
            SqlCommand cmd = new SqlCommand(sql, conexao);
            cmd.CommandType = CommandType.Text;
            SqlDataReader reader;
            conexao.Open();

            try
            {
                reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    MessageBox.Show("Cadastro realizado com sucesso");

                    btnLimpar.PerformClick();
                    cboIdNivelServico.Text = reader[0].ToString();
                    btnPesquisar.PerformClick();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());

            }
            finally
            {
                conexao.Close();
            }
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            if (ValidarDados() == false)
            {
                return;
            }

            string sql = "update produto set " +
               "nome_produto = '" + txtNome.Text + "'," +
               "descricao_produto = '" + txtDescricao.Text + "', " +
               "custo_de_pedido_produto = '" + txtCustoPedido.Text + "', " +
               "custo_de_aquisicao_produto = '" + txtCustoAquisicao.Text + "', " +
               "percentual_de_custo_de_aquisicao_produto = '" + txtPcAquisicao.Text + "', " +
               "custo_de_armazenagem_produto = '" + txtCa.Text + "', " +
               "percentual_de_custo_de_armazenagem_produto ='" + txtPcArmazenagem.Text + "', " +
               "obs_produto = '" + txtObs.Text + "', " +
               "status_produto = '" + cboStatus.Text + "', " +
               "id_categoria = '" + cboIdCategoria.Text + "', " +
               "id_nivel_servico = '" + cboIdNivelServico.Text + "', " +
               "id_fornecedor = '" + cbValorFornecedor.Text + "', " +
               "codigo_produto = '" + txtCodigo.Text + "', " +
               "descricao2_produto = '" + txtDescricao2.Text + "', " +
               "codigosBarras_produto = '" + txtCodbarras.Text + "' " +

               "where id_produto = " + cboIdNivelServico.Text;

            SqlConnection conn = new SqlConnection(strConexao);
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.CommandType = CommandType.Text;

            try
            {
                conn.Open();

                int i = cmd.ExecuteNonQuery();
                if (i == 1)
                {
                    MessageBox.Show("Alteração feita com sucesso");

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro: " + ex.ToString());
            }
            finally
            {
                conn.Close();
            }
        }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {


            string sql = "select * from produto where id_produto =" + cboIdNivelServico.Text;

            SqlConnection conexao = new SqlConnection(strConexao);
            SqlCommand cmd = new SqlCommand(sql, conexao);
            cmd.CommandType = CommandType.Text;
            SqlDataReader reader;
            conexao.Open();

            try
            {
                reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    cboIdNivelServico.Text = reader[0].ToString();
                    txtNome.Text = reader[1].ToString();
                    txtDescricao.Text = reader[2].ToString();
                    txtCustoPedido.Text = reader[3].ToString();
                    txtCustoAquisicao.Text = reader[4].ToString();
                    txtPcAquisicao.Text = reader[5].ToString();
                    txtCa.Text = reader[6].ToString();
                    txtPcArmazenagem.Text = reader[7].ToString();
                    cboStatus.Text = reader[8].ToString();
                    txtObs.Text = reader[9].ToString();
                    cbValorFornecedor.Text = reader[10].ToString();
                    cboIdCategoria.Text = reader[11].ToString();
                    cboIdNivelServico.Text = reader[12].ToString();
                    txtCodigo.Text = reader[13].ToString();
                    txtDescricao2.Text = reader[14].ToString();
                    txtCodbarras.Text = reader[15].ToString();


                }
                else
                {
                    MessageBox.Show("Código do usuario inexistente!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                conexao.Close();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            cboIdNivelServico.Text = "";
            txtNome.Text = "";
            txtCustoPedido.Text = "";
            txtCustoAquisicao.Text = "";
            txtPcAquisicao.Text = "";
            txtCa.Text = "";
            txtPcArmazenagem.Text = "";
            cboStatus.Text = "";
            txtObs.Text = "";
            cbValorFornecedor.Text = "";
            cboIdCategoria.Text = "";
            cboIdNivelServico.Text = "";
            txtCodigo.Text = "";
            txtDescricao.Text = "";
            txtCodbarras.Text = "";

        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            string sql = "delete from produto where id_produto = " + cboIdNivelServico.Text;
            SqlConnection conn = new SqlConnection(strConexao);
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.CommandType = CommandType.Text;

            try
            {
                conn.Open();

                int i = cmd.ExecuteNonQuery();
                if (i > 0)
                {
                    MessageBox.Show("Cadastro excluido sucesso");
                    btnLimpar.PerformClick();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro: " + ex.ToString);

            }
            finally
            {
                conn.Close();
            }
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            this.Close();

        }

        private void produto_Load(object sender, EventArgs e)
        {
            conexao();
            CarregarCombo();
            CarregarComboCAT();
            CarregarComboNV();


        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        //private void txtId_TextChanged(object sender, EventArgs e)

        private void textBox1_TextChanged(object sender, EventArgs e)
        //private void txtId_TextChanged(object sender, EventArgs e)
        {

        }

        int n1;
        private bool ValidarDados()
        {
            if (int.TryParse(txtNome.Text, out n1) == true)
            {
                MessageBox.Show("Campo deve conter nome");
                txtNome.Focus();
                txtNome.Text = "";

                return false;
            }

            if (txtNome.Text == "")
            {
                MessageBox.Show("Campo deve ser preenchido!");
                txtNome.Focus();
                txtNome.Text = "";

                return false;
            }

            /////////////////////////////////////////////////////////////////////////////////////////
            ///

            if (int.TryParse(txtDescricao.Text, out n1) == true)
            {
                MessageBox.Show("Campo deve conter descrição");
                txtDescricao.Focus();
                txtDescricao.Text = "";

                return false;
            }

            if (txtDescricao.Text == "")
            {
                MessageBox.Show("Campo deve ser preenchido");
                txtDescricao.Focus();
                txtDescricao.Text = "";

                return false;
            }

            /////////////////////////////////////////////////////////////////////////////////////////

            if (!int.TryParse(txtCustoPedido.Text, out n1) == true)
            {
                MessageBox.Show("Campo deve conter custo pedido");
                txtCustoPedido.Focus();
                txtCustoPedido.Text = "";

                return false;
            }

            if (txtCustoPedido.Text == "")
            {
                MessageBox.Show("Campo deve ser preenchido");
                txtCustoPedido.Focus();
                txtCustoPedido.Text = "";

                return false;
            }

            /////////////////////////////////////////////////////////////////////////////////////////
            ///

            if (!int.TryParse(txtCustoAquisicao.Text, out n1) == true)
            {
                MessageBox.Show("Campo deve conter custo aquisição");
                txtCustoAquisicao.Focus();
                txtCustoAquisicao.Text = "";

                return false;
            }

            if (txtCustoAquisicao.Text == "")
            {
                MessageBox.Show("Campo deve ser preenchido");
                txtCustoAquisicao.Focus();
                txtCustoAquisicao.Text = "";

                return false;
            }

            /////////////////////////////////////////////////////////////////////////////////////////
            ///

            if (!int.TryParse(txtPcAquisicao.Text, out n1) == true)
            {
                MessageBox.Show("Campo deve conter custo aquisição");
                txtPcAquisicao.Focus();
                txtPcAquisicao.Text = "";

                return false;
            }

            if (txtPcAquisicao.Text == "")
            {
                MessageBox.Show("Campo deve conter custo aquisição");
                txtPcAquisicao.Focus();
                txtPcAquisicao.Text = "";

                return false;
            }

            /////////////////////////////////////////////////////////////////////////////////////////
            ///

            if (!int.TryParse(txtPcAquisicao.Text, out n1) == true)
            {
                MessageBox.Show("Campo deve conter percentual de custo de aquisição");
                txtPcAquisicao.Focus();
                txtPcAquisicao.Text = "";

                return false;
            }

            if (txtPcAquisicao.Text == "")
            {
                MessageBox.Show("Campo deve ser preenchido");
                txtPcAquisicao.Focus();
                txtPcAquisicao.Text = "";

                return false;
            }

            /////////////////////////////////////////////////////////////////////////////////////////
            ///

            if (!int.TryParse(txtCa.Text, out n1) == true)
            {
                MessageBox.Show("Campo deve conter custo aquisição");
                txtCa.Focus();
                txtCa.Text = "";

                return false;
            }

            if (txtCa.Text == "")
            {
                MessageBox.Show("Campo deve ser preenchido");
                txtCa.Focus();
                txtCa.Text = "";

                return false;
            }

            /////////////////////////////////////////////////////////////////////////////////////////
            ///

            if (!int.TryParse(txtPcArmazenagem.Text, out n1) == true)
            {
                MessageBox.Show("Campo deve conter percentual de custo de armazenagem");
                txtPcArmazenagem.Focus();
                txtPcArmazenagem.Text = "";

                return false;
            }

            if (txtPcArmazenagem.Text == "")
            {
                MessageBox.Show("Campo deve ser preenchido");
                txtPcArmazenagem.Focus();
                txtPcArmazenagem.Text = "";

                return false;
            }

            /////////////////////////////////////////////////////////////////////////////////////////
            ///

            if (cbValorFornecedor.Text == "")
            {
                MessageBox.Show("Campo deve ser preenchido");
                cbValorFornecedor.Focus();
                cbValorFornecedor.Text = "";
                return false;
            }

            return true;
        }

        private void cboValorCat_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void cbValorNV_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void cbValorFornecedor_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void btnExportarDados_Click(object sender, EventArgs e)
        {
            // Definindo o nome do arquivo CSV com a data e hora atual
            string nomeArquivo = "produtos_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".csv";

            // Definindo o caminho completo do arquivo
            string caminhoArquivo = @"C:\Users\joao.vlquiroga\source\repos\sistema" + nomeArquivo;

            try
            {
                // Abrindo uma conexão com o banco de dados
                using (SqlConnection conexao = new SqlConnection(strConexao))
                {
                    // Consulta SQL para selecionar todos os dados da tabela produto
                    string consulta = "SELECT * FROM produto";

                    // Criando o comando SQL e abrindo a conexão
                    using (SqlCommand comando = new SqlCommand(consulta, conexao))
                    {
                        conexao.Open();

                        // Usando um DataReader para ler os resultados da consulta
                        using (SqlDataReader reader = comando.ExecuteReader())
                        {
                            // Usando StreamWriter para escrever os dados no arquivo CSV
                            using (StreamWriter writer = new StreamWriter(caminhoArquivo, false, Encoding.UTF8))
                            {
                                // Escrevendo o cabeçalho do arquivo CSV
                                writer.WriteLine("id_produto,nome_produto,descricao_produto,custo_de_pedido_produto,custo_de_aquisicao_produto,percentual_de_custo_de_aquisicao_produto,custo_de_armazenagem_produto,percentual_de_custo_de_armazenagem_produto,obs_produto,status_produto,id_categoria,id_nivel_servico,id_fornecedor");

                                // Iterando sobre os resultados da consulta e escrevendo no arquivo CSV
                                while (reader.Read())
                                {
                                    // Escrevendo uma linha no arquivo CSV para cada registro da tabela produto
                                    writer.WriteLine(string.Format("{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12}",
                                        reader["id_produto"], reader["nome_produto"], reader["descricao_produto"],
                                        reader["custo_de_pedido_produto"], reader["custo_de_aquisicao_produto"],
                                        reader["percentual_de_custo_de_aquisicao_produto"], reader["custo_de_armazenagem_produto"],
                                        reader["percentual_de_custo_de_armazenagem_produto"], reader["obs_produto"],
                                        reader["status_produto"], reader["id_categoria"], reader["id_nivel_servico"],
                                        reader["id_fornecedor"]));
                                }
                            }
                        }
                    }
                }

                MessageBox.Show("Dados exportados com sucesso para: " + caminhoArquivo);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao exportar dados: " + ex.Message);
            }
        }

        private void label16_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            parametroEstoque param = new parametroEstoque();
            param.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                string[] lines = File.ReadAllLines(ofd.FileName);
                foreach (string line in lines)
                {
                    string[] data = line.Split(';'); // Mudança para usar separador ';'
                    int produtoId = int.Parse(data[0]);

                    // Verificar se o ProdutoId existe na tabela Produtos
                    bool produtoExiste = false;
                    using (SqlConnection conn = new SqlConnection(strConexao))
                    {
                        conn.Open();
                        SqlCommand checkCmd = new SqlCommand("SELECT COUNT(1) FROM produto WHERE id_produto = @ProdutoId", conn);
                        checkCmd.Parameters.AddWithValue("@ProdutoId", produtoId);
                        produtoExiste = (int)checkCmd.ExecuteScalar() > 0;
                    }

                    if (produtoExiste)
                    {
                        for (int i = 1; i <= 6; i++)
                        {
                            int quantidade = int.Parse(data[i]);
                            using (SqlConnection conn = new SqlConnection(strConexao))
                            {
                                conn.Open();
                                SqlCommand cmd = new SqlCommand("INSERT INTO demanda (id_produto, periodo_demanda, quantidade_demanda) VALUES (@ProdutoId, @Periodo, @Quantidade)", conn);
                                cmd.Parameters.AddWithValue("@ProdutoId", produtoId);
                                cmd.Parameters.AddWithValue("@Periodo", i);
                                cmd.Parameters.AddWithValue("@Quantidade", quantidade);
                                cmd.ExecuteNonQuery();
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show($"ProdutoId {produtoId} não encontrado na tabela Produtos. A demanda não será inserida para este produto.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void btnSalvar2_Click(object sender, EventArgs e)
        {


        }

        private void btnGerarPdf_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "PDF files (*.pdf)|*.pdf";
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                using (FileStream fs = new FileStream(sfd.FileName, FileMode.Create, FileAccess.Write, FileShare.None))
                {
                    Document doc = new Document();
                    PdfWriter writer = PdfWriter.GetInstance(doc, fs);
                    doc.Open();

                    PdfPTable table = new PdfPTable(1);

                    using (SqlConnection conn = new SqlConnection(strConexao))
                    {
                        conn.Open();
                        SqlCommand cmd = new SqlCommand("SELECT codigoBarras_produto, descricao2_produto FROM produto", conn);
                        SqlDataReader reader = cmd.ExecuteReader();
                        while (reader.Read())
                        {
                            string codigoBarras = reader["codigoBarras_produto"].ToString().PadLeft(13, '0'); // Completar com zeros à esquerda
                            string descricao = reader["descricao2_produto"].ToString();

                            BarcodeEAN barcode = new BarcodeEAN();
                            barcode.CodeType = Barcode.EAN13;
                            barcode.Code = codigoBarras;

                            PdfPCell cell = new PdfPCell(barcode.CreateImageWithBarcode(writer.DirectContent, null, null));
                            cell.HorizontalAlignment = Element.ALIGN_CENTER;
                            table.AddCell(cell);

                            cell = new PdfPCell(new Phrase(descricao));
                            cell.HorizontalAlignment = Element.ALIGN_CENTER;
                            table.AddCell(cell);
                        }
                        reader.Close();
                    }

                    doc.Add(table);
                    doc.Close();
                }

            }
        }

        private void btnGerarUmPdf_Click(object sender, EventArgs e)
        {
            string codigoBarras = txtCodbarras.Text;
            string descricao = txtDescricao2.Text;

            // Validar o código de barras
            if (codigoBarras.Length != 13 || !codigoBarras.All(char.IsDigit))
            {
                MessageBox.Show("O código de barras deve ter exatamente 13 dígitos numéricos.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "PDF files (*.pdf)|*.pdf";
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                using (FileStream fs = new FileStream(sfd.FileName, FileMode.Create, FileAccess.Write, FileShare.None))
                {
                    Document doc = new Document();
                    PdfWriter writer = PdfWriter.GetInstance(doc, fs);
                    doc.Open();

                    BarcodeEAN barcode = new BarcodeEAN();
                    barcode.CodeType = Barcode.EAN13;
                    barcode.Code = codigoBarras;

                    PdfPCell cell = new PdfPCell(barcode.CreateImageWithBarcode(writer.DirectContent, null, null));
                    cell.HorizontalAlignment = Element.ALIGN_CENTER;
                    PdfPTable table = new PdfPTable(1);
                    table.AddCell(cell);

                    cell = new PdfPCell(new Phrase(descricao));
                    cell.HorizontalAlignment = Element.ALIGN_CENTER;
                    table.AddCell(cell);

                    doc.Add(table);
                    doc.Close();
                }
            }
        }

        private void cboIdCategoria_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }

        private void cboValorCat_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }

        private void cboIdFornecedor_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }

        private void cbValorFornecedor_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }

        private void cboIdNivelServico_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }

        private void cbValorNV_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }

        private void btnGerarUmPdf_Click_1(object sender, EventArgs e)
        {
            string codigoBarras = txtCodbarras.Text;
            string descricao = txtDescricao2.Text;

            // Validar o código de barras
            if (codigoBarras.Length != 13 || !codigoBarras.All(char.IsDigit))
            {
                MessageBox.Show("O código de barras deve ter exatamente 13 dígitos numéricos.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "PDF files (*.pdf)|*.pdf";
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                using (FileStream fs = new FileStream(sfd.FileName, FileMode.Create, FileAccess.Write, FileShare.None))
                {
                    Document doc = new Document();
                    PdfWriter writer = PdfWriter.GetInstance(doc, fs);
                    doc.Open();

                    BarcodeEAN barcode = new BarcodeEAN();
                    barcode.CodeType = Barcode.EAN13;
                    barcode.Code = codigoBarras;

                    PdfPCell cell = new PdfPCell(barcode.CreateImageWithBarcode(writer.DirectContent, null, null));
                    cell.HorizontalAlignment = Element.ALIGN_CENTER;
                    PdfPTable table = new PdfPTable(1);
                    table.AddCell(cell);

                    cell = new PdfPCell(new Phrase(descricao));
                    cell.HorizontalAlignment = Element.ALIGN_CENTER;
                    table.AddCell(cell);

                    doc.Add(table);
                    doc.Close();
                }
            }
        }

        private void btnGerarPdf_Click_1(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "PDF files (*.pdf)|*.pdf";
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                using (FileStream fs = new FileStream(sfd.FileName, FileMode.Create, FileAccess.Write, FileShare.None))
                {
                    Document doc = new Document();
                    PdfWriter writer = PdfWriter.GetInstance(doc, fs);
                    doc.Open();

                    PdfPTable table = new PdfPTable(1);

                    using (SqlConnection conn = new SqlConnection(strConexao))
                    {
                        conn.Open();
                        SqlCommand cmd = new SqlCommand("SELECT codigoBarras_produto, descricao2_produto FROM produto", conn);
                        SqlDataReader reader = cmd.ExecuteReader();
                        while (reader.Read())
                        {
                            string codigoBarras = reader["codigoBarras_produto"].ToString().PadLeft(13, '0'); // Completar com zeros à esquerda
                            string descricao = reader["descricao2_produto"].ToString();

                            BarcodeEAN barcode = new BarcodeEAN();
                            barcode.CodeType = Barcode.EAN13;
                            barcode.Code = codigoBarras;

                            PdfPCell cell = new PdfPCell(barcode.CreateImageWithBarcode(writer.DirectContent, null, null));
                            cell.HorizontalAlignment = Element.ALIGN_CENTER;
                            table.AddCell(cell);

                            cell = new PdfPCell(new Phrase(descricao));
                            cell.HorizontalAlignment = Element.ALIGN_CENTER;
                            table.AddCell(cell);
                        }
                        reader.Close();
                    }

                    doc.Add(table);
                    doc.Close();
                }

            }
        }

        private void btnParametros_Click(object sender, EventArgs e)
        {
            parametroEstoque param = new parametroEstoque();
            param.Show();
            this.Hide();
        }

        private void btnExportarDados_Click_1(object sender, EventArgs e)
        {
            // Definindo o nome do arquivo CSV com a data e hora atual
            string nomeArquivo = "produtos_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".csv";

            // Definindo o caminho completo do arquivo
            string caminhoArquivo = @"C:\Users\joao.vlquiroga\source\repos\sistema" + nomeArquivo;

            try
            {
                // Abrindo uma conexão com o banco de dados
                using (SqlConnection conexao = new SqlConnection(strConexao))
                {
                    // Consulta SQL para selecionar todos os dados da tabela produto
                    string consulta = "SELECT * FROM produto";

                    // Criando o comando SQL e abrindo a conexão
                    using (SqlCommand comando = new SqlCommand(consulta, conexao))
                    {
                        conexao.Open();

                        // Usando um DataReader para ler os resultados da consulta
                        using (SqlDataReader reader = comando.ExecuteReader())
                        {
                            // Usando StreamWriter para escrever os dados no arquivo CSV
                            using (StreamWriter writer = new StreamWriter(caminhoArquivo, false, Encoding.UTF8))
                            {
                                // Escrevendo o cabeçalho do arquivo CSV
                                writer.WriteLine("id_produto,nome_produto,descricao_produto,custo_de_pedido_produto,custo_de_aquisicao_produto,percentual_de_custo_de_aquisicao_produto,custo_de_armazenagem_produto,percentual_de_custo_de_armazenagem_produto,obs_produto,status_produto,id_categoria,id_nivel_servico,id_fornecedor");

                                // Iterando sobre os resultados da consulta e escrevendo no arquivo CSV
                                while (reader.Read())
                                {
                                    // Escrevendo uma linha no arquivo CSV para cada registro da tabela produto
                                    writer.WriteLine(string.Format("{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12}",
                                        reader["id_produto"], reader["nome_produto"], reader["descricao_produto"],
                                        reader["custo_de_pedido_produto"], reader["custo_de_aquisicao_produto"],
                                        reader["percentual_de_custo_de_aquisicao_produto"], reader["custo_de_armazenagem_produto"],
                                        reader["percentual_de_custo_de_armazenagem_produto"], reader["obs_produto"],
                                        reader["status_produto"], reader["id_categoria"], reader["id_nivel_servico"],
                                        reader["id_fornecedor"]));
                                }
                            }
                        }
                    }
                }

                MessageBox.Show("Dados exportados com sucesso para: " + caminhoArquivo);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao exportar dados: " + ex.Message);
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {

            if (ValidarDados() == false)
            {
                return;
            }

            string sql = "insert into produto" +
                "(" +
                    "nome_produto," +
                    "descricao_produto," +
                    "custo_de_pedido_produto," +
                    "custo_de_aquisicao_produto," +
                    "percentual_de_custo_de_aquisicao_produto," +
                    "custo_de_armazenagem_produto," +
                    "percentual_de_custo_de_armazenagem_produto," +
                    "obs_produto," +
                    "status_produto," +
                    "id_categoria, " +
                    "id_nivel_servico, " +
                    "id_fornecedor, " +
                    "descricao2_produto, " +
                    "codigoBarras_produto, " +

                ")" +
                "values" +
                "(" +
                    "'" + txtNome.Text + "'," +
                    "'" + txtDescricao.Text + "'," +
                    "'" + txtCustoPedido.Text + "'," +
                    "'" + txtCustoAquisicao.Text + "'," +
                    "'" + txtPcAquisicao.Text + "'," +
                    "'" + txtCa.Text + "'," +
                    "'" + txtPcArmazenagem.Text + "'," +
                    "'" + txtObs.Text + "'," +
                    "'" + cboStatus.Text + "'," +
                    "'" + cboValorCat.Text + "'," +
                    "'" + cbValorNV.Text + "', " +
                    "'" + cbValorFornecedor.Text + "', " +
                    "'" + txtDescricao2.Text + "', " +
                    "'" + txtCodbarras.Text + "' " +

                ")select SCOPE_IDENTITY()";

            SqlConnection conexao = new SqlConnection(strConexao);
            SqlCommand cmd = new SqlCommand(sql, conexao);
            cmd.CommandType = CommandType.Text;
            SqlDataReader reader;
            conexao.Open();

            try
            {
                reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    MessageBox.Show("Cadastro realizado com sucesso");

                    btnLimpar.PerformClick();
                    txtCodigo.Text = reader[0].ToString();
                    btnPesquisar.PerformClick();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());

            }
            finally
            {
                conexao.Close();
            }
        }

        private void btnAlterar_Click_1(object sender, EventArgs e)
        {
            if (ValidarDados() == false)
            {
                return;
            }

            double n1 = double.Parse(txtCustoPedido.Text);
            double n2 = double.Parse(txtCustoAquisicao.Text);
            double n3 = double.Parse(txtPcAquisicao.Text);
            double n4 = double.Parse(txtCa.Text);
            double n5 = double.Parse(txtPcArmazenagem.Text);

            float n6;
            float n7;
            float n8;
            float n9;
            float n10;



            string sql = "update produto set " +
               "nome_produto = '" + txtNome.Text + "'," +
               "descricao_produto = '" + txtDescricao.Text + "', " +
               "custo_de_pedido_produto = '" + txtCustoPedido.Text + "', " +
               "custo_de_aquisicao_produto = '" + txtCustoAquisicao.Text + "', " +
               "percentual_de_custo_de_aquisicao_produto = '" + txtPcAquisicao.Text + "', " +
               "custo_de_armazenagem_produto = '" + txtCa.Text + "', " +
               "percentual_de_custo_de_armazenagem_produto ='" + txtPcArmazenagem.Text + "', " +
               "obs_produto = '" + txtObs.Text + "', " +
               "status_produto = '" + cboStatus.Text + "', " +
               "id_categoria = '" + cboIdCategoria.Text + "', " +
               "id_nivel_servico = '" + cboIdNivelServico.Text + "', " +
               "id_fornecedor = '" + cboIdFornecedor.Text + "', " +
               "descricao2_produto = '" + txtDescricao2.Text + "', " +
               "codigoBarras_produto = '" + txtCodbarras.Text + "' " +

               "where id_produto = " + txtCodigo.Text;

            SqlConnection conn = new SqlConnection(strConexao);
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.CommandType = CommandType.Text;

            try
            {
                conn.Open();

                int i = cmd.ExecuteNonQuery();
                if (i == 1)
                {
                    MessageBox.Show("Alteração feita com sucesso");

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro: " + ex.ToString());
            }
            finally
            {
                conn.Close();
            }
        }
        

        private void btnPesquisar_Click_1(object sender, EventArgs e)
        {
            string sql = "select * from produto where id_produto =" + txtCodigo.Text;

            SqlConnection conexao = new SqlConnection(strConexao);
            SqlCommand cmd = new SqlCommand(sql, conexao);
            cmd.CommandType = CommandType.Text;
            SqlDataReader reader;
            conexao.Open();

            try
            {
                reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    txtCodigo.Text = reader[0].ToString();
                    txtNome.Text = reader[1].ToString();
                    txtDescricao.Text = reader[2].ToString();
                    txtCustoPedido.Text = reader[3].ToString();
                    txtCustoAquisicao.Text = reader[4].ToString();
                    txtPcAquisicao.Text = reader[5].ToString();
                    txtCa.Text = reader[6].ToString();
                    txtPcArmazenagem.Text = reader[7].ToString();
                    txtObs.Text = reader[8].ToString();
                    cboStatus.Text = reader[9].ToString();
                    cboIdFornecedor.Text = reader[10].ToString();
                    cboIdCategoria.Text = reader[11].ToString();
                    cboIdNivelServico.Text = reader[12].ToString();
                    txtDescricao2.Text = reader[13].ToString();
                    txtCodbarras.Text = reader[14].ToString();


                }
                else
                {
                    MessageBox.Show("Código do usuario inexistente!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                conexao.Close();
            }
        }

        private void btnLimpar_Click_1(object sender, EventArgs e)
        {
            txtCodigo.Text = "";
            txtNome.Text = "";
            txtCustoPedido.Text = "";
            txtCustoAquisicao.Text = "";
            txtPcAquisicao.Text = "";
            txtCa.Text = "";
            txtPcArmazenagem.Text = "";
            cboStatus.Text = "";
            txtObs.Text = "";
            cboIdFornecedor.Text = "";
            cboIdCategoria.Text = "";
            cboIdNivelServico.Text = "";
            txtDescricao.Text = "";
            txtCodbarras.Text = "";
        }

        private void btnExcluir_Click_1(object sender, EventArgs e)
        {
            string sql = "delete from produto where id_produto = " + txtCodigo.Text;
            SqlConnection conn = new SqlConnection(strConexao);
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.CommandType = CommandType.Text;

            try
            {
                conn.Open();

                int i = cmd.ExecuteNonQuery();
                if (i > 0)
                {
                    MessageBox.Show("Cadastro excluido sucesso");
                    btnLimpar.PerformClick();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro: " + ex.ToString);

            }
            finally
            {
                conn.Close();
            }
        }

        private void btnImportar_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                string[] lines = File.ReadAllLines(ofd.FileName);
                foreach (string line in lines)
                {
                    string[] data = line.Split(';'); // Mudança para usar separador ';'
                    int produtoId = int.Parse(data[0]);

                    // Verificar se o ProdutoId existe na tabela Produtos
                    bool produtoExiste = false;
                    using (SqlConnection conn = new SqlConnection(strConexao))
                    {
                        conn.Open();
                        SqlCommand checkCmd = new SqlCommand("SELECT COUNT(1) FROM produto WHERE id_produto = @id_produto", conn);
                        checkCmd.Parameters.AddWithValue("@id_produto", produtoId);
                        produtoExiste = (int)checkCmd.ExecuteScalar() > 0;
                    }

                    if (produtoExiste)
                    {
                        for (int i = 1; i <= data.Length; i++)
                        {
                            int quantidade;
                            if (int.TryParse(data[i], out quantidade))
                            {
                                using (SqlConnection conn = new SqlConnection(strConexao))
                                {
                                    conn.Open();
                                    SqlCommand cmd = new SqlCommand("INSERT INTO demanda (id_produto, periodo_demanda, quantidade_demanda) VALUES (@ProdutoId, @Periodo, @Quantidade)", conn);
                                    cmd.Parameters.AddWithValue("@ProdutoId", produtoId);
                                    cmd.Parameters.AddWithValue("@Periodo", i); // 'i' representa o período (começa em 1)
                                    cmd.Parameters.AddWithValue("@Quantidade", quantidade);
                                    cmd.ExecuteNonQuery();
                                }
                            }
                            else
                            {
                                MessageBox.Show($"Quantidade inválida no período {i} para o produtoId {produtoId}.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show($"ProdutoId {produtoId} não encontrado na tabela Produtos. A demanda não será inserida para este produto.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void btnFechar_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void groupBox4_Enter(object sender, EventArgs e)
        {

        }

        private void produto_Load_1(object sender, EventArgs e)
        {
            conexao();
            CarregarCombo();
            CarregarComboCAT();
            CarregarComboNV();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}

        