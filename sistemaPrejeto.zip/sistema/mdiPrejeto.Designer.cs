﻿namespace sistema
{
    partial class mdiPrejeto
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.lbProduto = new System.Windows.Forms.Label();
            this.lbParametroEstoque = new System.Windows.Forms.Label();
            this.lbCat = new System.Windows.Forms.Label();
            this.lbNV = new System.Windows.Forms.Label();
            this.lbFornecedor = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.CadetBlue;
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.lbProduto);
            this.panel1.Controls.Add(this.lbParametroEstoque);
            this.panel1.Controls.Add(this.lbCat);
            this.panel1.Controls.Add(this.lbNV);
            this.panel1.Controls.Add(this.lbFornecedor);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(223, 527);
            this.panel1.TabIndex = 2;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.IndianRed;
            this.panel2.Location = new System.Drawing.Point(258, 41);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(559, 526);
            this.panel2.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("SansSerif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(12, 269);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 19);
            this.label1.TabIndex = 5;
            this.label1.Text = "Sair";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // lbProduto
            // 
            this.lbProduto.AutoSize = true;
            this.lbProduto.Font = new System.Drawing.Font("SansSerif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbProduto.Location = new System.Drawing.Point(12, 25);
            this.lbProduto.Name = "lbProduto";
            this.lbProduto.Size = new System.Drawing.Size(80, 19);
            this.lbProduto.TabIndex = 1;
            this.lbProduto.Text = "Produtos";
            this.lbProduto.Click += new System.EventHandler(this.lbProduto_Click_1);
            // 
            // lbParametroEstoque
            // 
            this.lbParametroEstoque.AutoSize = true;
            this.lbParametroEstoque.Font = new System.Drawing.Font("SansSerif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbParametroEstoque.ForeColor = System.Drawing.Color.Black;
            this.lbParametroEstoque.Location = new System.Drawing.Point(12, 213);
            this.lbParametroEstoque.Name = "lbParametroEstoque";
            this.lbParametroEstoque.Size = new System.Drawing.Size(186, 19);
            this.lbParametroEstoque.TabIndex = 2;
            this.lbParametroEstoque.Text = "Parâmetros de estoque";
            this.lbParametroEstoque.Click += new System.EventHandler(this.lbParametroEstoque_Click_1);
            // 
            // lbCat
            // 
            this.lbCat.AutoSize = true;
            this.lbCat.Font = new System.Drawing.Font("SansSerif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbCat.Location = new System.Drawing.Point(12, 69);
            this.lbCat.Name = "lbCat";
            this.lbCat.Size = new System.Drawing.Size(92, 19);
            this.lbCat.TabIndex = 3;
            this.lbCat.Text = "Categorias";
            this.lbCat.Click += new System.EventHandler(this.lbCat_Click);
            // 
            // lbNV
            // 
            this.lbNV.AutoSize = true;
            this.lbNV.Font = new System.Drawing.Font("SansSerif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbNV.Location = new System.Drawing.Point(12, 162);
            this.lbNV.Name = "lbNV";
            this.lbNV.Size = new System.Drawing.Size(130, 19);
            this.lbNV.TabIndex = 4;
            this.lbNV.Text = "Nivel de serviço";
            this.lbNV.Click += new System.EventHandler(this.lbNV_Click_1);
            // 
            // lbFornecedor
            // 
            this.lbFornecedor.AutoSize = true;
            this.lbFornecedor.Font = new System.Drawing.Font("SansSerif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbFornecedor.Location = new System.Drawing.Point(12, 115);
            this.lbFornecedor.Name = "lbFornecedor";
            this.lbFornecedor.Size = new System.Drawing.Size(116, 19);
            this.lbFornecedor.TabIndex = 0;
            this.lbFornecedor.Text = "Fornecedores";
            this.lbFornecedor.Click += new System.EventHandler(this.lbFornecedor_Click_1);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::sistema.Properties.Resources.fechar;
            this.pictureBox1.Location = new System.Drawing.Point(1475, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(109, 83);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // mdiPrejeto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoValidate = System.Windows.Forms.AutoValidate.Disable;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(1592, 527);
            this.ControlBox = false;
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.IsMdiContainer = true;
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "mdiPrejeto";
            this.ShowIcon = false;
            this.Text = "mdiPrejeto";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.mdiPrejeto_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }
        #endregion

        private System.Windows.Forms.ToolTip toolTip;
        private Panel panel1;
        private Label lbFornecedor;
        private Label lbProduto;
        private Label lbNV;
        private Label lbCat;
        private Label lbParametroEstoque;
        private Label label1;
        private Panel panel2;
        private PictureBox pictureBox1;
    }
}



