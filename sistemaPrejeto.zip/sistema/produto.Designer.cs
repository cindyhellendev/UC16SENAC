﻿namespace sistema
{
    partial class produto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtId = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtPcArmazenagem = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtCa = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtPcAquisicao = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtCustoAquisicao = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtCustoPedido = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnGerarPdf = new System.Windows.Forms.Button();
            this.btnParametros = new System.Windows.Forms.Button();
            this.txtCodbarras = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtDescricao2 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtCodigo = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.btnImportar = new System.Windows.Forms.Button();
            this.cbValorFornecedor = new System.Windows.Forms.ComboBox();
            this.cbValorNV = new System.Windows.Forms.ComboBox();
            this.cboValorCat = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.cboStatus = new System.Windows.Forms.ComboBox();
            this.txtObs = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtDescricao = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.cboIdFornecedor = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.cboIdNivelServico = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.cboIdCategoria = new System.Windows.Forms.ComboBox();
            this.btnExportarDados = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnFechar = new System.Windows.Forms.Button();
            this.btnExcluir = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnPesquisar = new System.Windows.Forms.Button();
            this.btnAlterar = new System.Windows.Forms.Button();
            this.btnSalvar = new System.Windows.Forms.Button();
            this.btnGerarUmPdf = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtId);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.txtPcArmazenagem);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.txtCa);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txtPcAquisicao);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txtCustoAquisicao);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtCustoPedido);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtNome);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(622, 175);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Produto";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // txtId
            // 
            this.txtId.Location = new System.Drawing.Point(382, 44);
            this.txtId.Name = "txtId";
            this.txtId.Size = new System.Drawing.Size(50, 25);
            this.txtId.TabIndex = 13;
            this.txtId.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(350, 47);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(23, 19);
            this.label13.TabIndex = 12;
            this.label13.Text = "ID";
            // 
            // txtPcArmazenagem
            // 
            this.txtPcArmazenagem.Location = new System.Drawing.Point(533, 126);
            this.txtPcArmazenagem.Name = "txtPcArmazenagem";
            this.txtPcArmazenagem.Size = new System.Drawing.Size(50, 25);
            this.txtPcArmazenagem.TabIndex = 6;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(281, 126);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(246, 19);
            this.label12.TabIndex = 10;
            this.label12.Text = "Percentual de Custo de Armazenagem";
            // 
            // txtCa
            // 
            this.txtCa.Location = new System.Drawing.Point(179, 123);
            this.txtCa.Name = "txtCa";
            this.txtCa.Size = new System.Drawing.Size(96, 25);
            this.txtCa.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(15, 123);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(157, 19);
            this.label5.TabIndex = 8;
            this.label5.Text = "Custo de Armazenagem";
            // 
            // txtPcAquisicao
            // 
            this.txtPcAquisicao.Location = new System.Drawing.Point(464, 79);
            this.txtPcAquisicao.Name = "txtPcAquisicao";
            this.txtPcAquisicao.Size = new System.Drawing.Size(96, 25);
            this.txtPcAquisicao.TabIndex = 4;
            this.txtPcAquisicao.TextChanged += new System.EventHandler(this.txPcAquisicao_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(240, 79);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(218, 19);
            this.label4.TabIndex = 6;
            this.label4.Text = "Percentual de Custo de Aquisição";
            // 
            // txtCustoAquisicao
            // 
            this.txtCustoAquisicao.Location = new System.Drawing.Point(138, 79);
            this.txtCustoAquisicao.Name = "txtCustoAquisicao";
            this.txtCustoAquisicao.Size = new System.Drawing.Size(96, 25);
            this.txtCustoAquisicao.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(15, 82);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(127, 19);
            this.label3.TabIndex = 4;
            this.label3.Text = "Custo de aquisição";
            // 
            // txtCustoPedido
            // 
            this.txtCustoPedido.Location = new System.Drawing.Point(287, 44);
            this.txtCustoPedido.Name = "txtCustoPedido";
            this.txtCustoPedido.Size = new System.Drawing.Size(58, 25);
            this.txtCustoPedido.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(178, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(115, 19);
            this.label2.TabIndex = 2;
            this.label2.Text = "Custo de pedido ";
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(66, 44);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(106, 25);
            this.txtNome.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nome";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnGerarUmPdf);
            this.groupBox2.Controls.Add(this.btnGerarPdf);
            this.groupBox2.Controls.Add(this.btnParametros);
            this.groupBox2.Controls.Add(this.txtCodbarras);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.txtDescricao2);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.txtCodigo);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.btnImportar);
            this.groupBox2.Controls.Add(this.cbValorFornecedor);
            this.groupBox2.Controls.Add(this.cbValorNV);
            this.groupBox2.Controls.Add(this.cboValorCat);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.cboStatus);
            this.groupBox2.Controls.Add(this.txtObs);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.txtDescricao);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.cboIdFornecedor);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.cboIdNivelServico);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.cboIdCategoria);
            this.groupBox2.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.groupBox2.Location = new System.Drawing.Point(12, 183);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(622, 396);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            // 
            // btnGerarPdf
            // 
            this.btnGerarPdf.Location = new System.Drawing.Point(369, 250);
            this.btnGerarPdf.Name = "btnGerarPdf";
            this.btnGerarPdf.Size = new System.Drawing.Size(99, 36);
            this.btnGerarPdf.TabIndex = 30;
            this.btnGerarPdf.Text = "Gerar PDF";
            this.btnGerarPdf.UseVisualStyleBackColor = true;
            this.btnGerarPdf.Click += new System.EventHandler(this.btnGerarPdf_Click);
            // 
            // btnParametros
            // 
            this.btnParametros.Location = new System.Drawing.Point(290, 208);
            this.btnParametros.Name = "btnParametros";
            this.btnParametros.Size = new System.Drawing.Size(96, 36);
            this.btnParametros.TabIndex = 29;
            this.btnParametros.Text = "Parametros";
            this.btnParametros.UseVisualStyleBackColor = true;
            this.btnParametros.Click += new System.EventHandler(this.button2_Click);
            // 
            // txtCodbarras
            // 
            this.txtCodbarras.Location = new System.Drawing.Point(15, 174);
            this.txtCodbarras.Name = "txtCodbarras";
            this.txtCodbarras.Size = new System.Drawing.Size(133, 27);
            this.txtCodbarras.TabIndex = 28;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(15, 151);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(126, 20);
            this.label16.TabIndex = 27;
            this.label16.Text = "Codigo de barras";
            // 
            // txtDescricao2
            // 
            this.txtDescricao2.Location = new System.Drawing.Point(76, 235);
            this.txtDescricao2.Name = "txtDescricao2";
            this.txtDescricao2.Size = new System.Drawing.Size(183, 27);
            this.txtDescricao2.TabIndex = 26;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(76, 212);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(75, 20);
            this.label15.TabIndex = 25;
            this.label15.Text = "Descrição";
            // 
            // txtCodigo
            // 
            this.txtCodigo.Location = new System.Drawing.Point(12, 235);
            this.txtCodigo.Name = "txtCodigo";
            this.txtCodigo.Size = new System.Drawing.Size(58, 27);
            this.txtCodigo.TabIndex = 24;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(12, 212);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(58, 20);
            this.label14.TabIndex = 23;
            this.label14.Text = "Código";
            // 
            // btnImportar
            // 
            this.btnImportar.Location = new System.Drawing.Point(287, 250);
            this.btnImportar.Name = "btnImportar";
            this.btnImportar.Size = new System.Drawing.Size(76, 36);
            this.btnImportar.TabIndex = 22;
            this.btnImportar.Text = "Importar";
            this.btnImportar.UseVisualStyleBackColor = true;
            this.btnImportar.Click += new System.EventHandler(this.button1_Click);
            // 
            // cbValorFornecedor
            // 
            this.cbValorFornecedor.FormattingEnabled = true;
            this.cbValorFornecedor.Location = new System.Drawing.Point(418, 160);
            this.cbValorFornecedor.Name = "cbValorFornecedor";
            this.cbValorFornecedor.Size = new System.Drawing.Size(130, 28);
            this.cbValorFornecedor.TabIndex = 21;
            this.cbValorFornecedor.Visible = false;
            this.cbValorFornecedor.SelectedIndexChanged += new System.EventHandler(this.cbValorFornecedor_SelectedIndexChanged);
            // 
            // cbValorNV
            // 
            this.cbValorNV.FormattingEnabled = true;
            this.cbValorNV.Location = new System.Drawing.Point(418, 104);
            this.cbValorNV.Name = "cbValorNV";
            this.cbValorNV.Size = new System.Drawing.Size(130, 28);
            this.cbValorNV.TabIndex = 20;
            this.cbValorNV.Visible = false;
            this.cbValorNV.SelectedIndexChanged += new System.EventHandler(this.cbValorNV_SelectedIndexChanged);
            // 
            // cboValorCat
            // 
            this.cboValorCat.FormattingEnabled = true;
            this.cboValorCat.Location = new System.Drawing.Point(418, 40);
            this.cboValorCat.Name = "cboValorCat";
            this.cboValorCat.Size = new System.Drawing.Size(130, 28);
            this.cboValorCat.TabIndex = 19;
            this.cboValorCat.Visible = false;
            this.cboValorCat.SelectedIndexChanged += new System.EventHandler(this.cboValorCat_SelectedIndexChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(404, 302);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(50, 20);
            this.label11.TabIndex = 18;
            this.label11.Text = "Status";
            // 
            // cboStatus
            // 
            this.cboStatus.FormattingEnabled = true;
            this.cboStatus.Items.AddRange(new object[] {
            "ATIVO\t",
            "INATIVO"});
            this.cboStatus.Location = new System.Drawing.Point(460, 297);
            this.cboStatus.Name = "cboStatus";
            this.cboStatus.Size = new System.Drawing.Size(88, 28);
            this.cboStatus.TabIndex = 10;
            this.cboStatus.SelectedIndexChanged += new System.EventHandler(this.cboStatus_SelectedIndexChanged);
            // 
            // txtObs
            // 
            this.txtObs.Location = new System.Drawing.Point(15, 331);
            this.txtObs.Multiline = true;
            this.txtObs.Name = "txtObs";
            this.txtObs.Size = new System.Drawing.Size(533, 59);
            this.txtObs.TabIndex = 11;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(14, 305);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(90, 20);
            this.label10.TabIndex = 15;
            this.label10.Text = "Observação";
            // 
            // txtDescricao
            // 
            this.txtDescricao.Location = new System.Drawing.Point(7, 46);
            this.txtDescricao.Multiline = true;
            this.txtDescricao.Name = "txtDescricao";
            this.txtDescricao.Size = new System.Drawing.Size(236, 50);
            this.txtDescricao.TabIndex = 11;
            this.txtDescricao.TextChanged += new System.EventHandler(this.textBox6_TextChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(7, 23);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(75, 20);
            this.label9.TabIndex = 10;
            this.label9.Text = "Descrição";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(301, 137);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(88, 20);
            this.label8.TabIndex = 14;
            this.label8.Text = "Fornecedor";
            // 
            // cboIdFornecedor
            // 
            this.cboIdFornecedor.FormattingEnabled = true;
            this.cboIdFornecedor.Location = new System.Drawing.Point(301, 160);
            this.cboIdFornecedor.Name = "cboIdFornecedor";
            this.cboIdFornecedor.Size = new System.Drawing.Size(85, 28);
            this.cboIdFornecedor.TabIndex = 9;
            this.cboIdFornecedor.SelectedIndexChanged += new System.EventHandler(this.cboIdFornecedor_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(301, 76);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(121, 20);
            this.label7.TabIndex = 12;
            this.label7.Text = "Nivel de Serviço";
            // 
            // cboIdNivelServico
            // 
            this.cboIdNivelServico.FormattingEnabled = true;
            this.cboIdNivelServico.Location = new System.Drawing.Point(301, 104);
            this.cboIdNivelServico.Name = "cboIdNivelServico";
            this.cboIdNivelServico.Size = new System.Drawing.Size(85, 28);
            this.cboIdNivelServico.TabIndex = 8;
            this.cboIdNivelServico.TabStop = false;
            this.cboIdNivelServico.SelectedIndexChanged += new System.EventHandler(this.cboIdNivelServico_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(301, 17);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(75, 20);
            this.label6.TabIndex = 10;
            this.label6.Text = "Categoria";
            // 
            // cboIdCategoria
            // 
            this.cboIdCategoria.FormattingEnabled = true;
            this.cboIdCategoria.Location = new System.Drawing.Point(301, 40);
            this.cboIdCategoria.Name = "cboIdCategoria";
            this.cboIdCategoria.Size = new System.Drawing.Size(85, 28);
            this.cboIdCategoria.TabIndex = 7;
            this.cboIdCategoria.SelectedIndexChanged += new System.EventHandler(this.cboIdCategoria_SelectedIndexChanged);
            // 
            // btnExportarDados
            // 
            this.btnExportarDados.Location = new System.Drawing.Point(520, 19);
            this.btnExportarDados.Name = "btnExportarDados";
            this.btnExportarDados.Size = new System.Drawing.Size(96, 28);
            this.btnExportarDados.TabIndex = 22;
            this.btnExportarDados.Text = "Exportar Dados";
            this.btnExportarDados.UseVisualStyleBackColor = true;
            this.btnExportarDados.Click += new System.EventHandler(this.btnExportarDados_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnFechar);
            this.groupBox3.Controls.Add(this.btnExcluir);
            this.groupBox3.Controls.Add(this.btnLimpar);
            this.groupBox3.Controls.Add(this.btnPesquisar);
            this.groupBox3.Controls.Add(this.btnAlterar);
            this.groupBox3.Controls.Add(this.btnSalvar);
            this.groupBox3.Controls.Add(this.btnExportarDados);
            this.groupBox3.Location = new System.Drawing.Point(12, 585);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(622, 76);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            // 
            // btnFechar
            // 
            this.btnFechar.Location = new System.Drawing.Point(437, 19);
            this.btnFechar.Name = "btnFechar";
            this.btnFechar.Size = new System.Drawing.Size(80, 29);
            this.btnFechar.TabIndex = 5;
            this.btnFechar.Text = "Fechar";
            this.btnFechar.UseVisualStyleBackColor = true;
            this.btnFechar.Click += new System.EventHandler(this.btnFechar_Click);
            // 
            // btnExcluir
            // 
            this.btnExcluir.Location = new System.Drawing.Point(351, 19);
            this.btnExcluir.Name = "btnExcluir";
            this.btnExcluir.Size = new System.Drawing.Size(80, 29);
            this.btnExcluir.TabIndex = 4;
            this.btnExcluir.Text = "Excluir";
            this.btnExcluir.UseVisualStyleBackColor = true;
            this.btnExcluir.Click += new System.EventHandler(this.btnExcluir_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(265, 19);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(80, 29);
            this.btnLimpar.TabIndex = 3;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // btnPesquisar
            // 
            this.btnPesquisar.Location = new System.Drawing.Point(179, 19);
            this.btnPesquisar.Name = "btnPesquisar";
            this.btnPesquisar.Size = new System.Drawing.Size(80, 29);
            this.btnPesquisar.TabIndex = 2;
            this.btnPesquisar.Text = "Pesquisar";
            this.btnPesquisar.UseVisualStyleBackColor = true;
            this.btnPesquisar.Click += new System.EventHandler(this.btnPesquisar_Click);
            // 
            // btnAlterar
            // 
            this.btnAlterar.Location = new System.Drawing.Point(93, 19);
            this.btnAlterar.Name = "btnAlterar";
            this.btnAlterar.Size = new System.Drawing.Size(80, 29);
            this.btnAlterar.TabIndex = 1;
            this.btnAlterar.Text = "Alterar";
            this.btnAlterar.UseVisualStyleBackColor = true;
            this.btnAlterar.Click += new System.EventHandler(this.btnAlterar_Click);
            // 
            // btnSalvar
            // 
            this.btnSalvar.Location = new System.Drawing.Point(7, 19);
            this.btnSalvar.Name = "btnSalvar";
            this.btnSalvar.Size = new System.Drawing.Size(80, 29);
            this.btnSalvar.TabIndex = 0;
            this.btnSalvar.Text = "Salvar";
            this.btnSalvar.UseVisualStyleBackColor = true;
            this.btnSalvar.Click += new System.EventHandler(this.btnSalvar_Click);
            // 
            // btnGerarUmPdf
            // 
            this.btnGerarUmPdf.Location = new System.Drawing.Point(392, 208);
            this.btnGerarUmPdf.Name = "btnGerarUmPdf";
            this.btnGerarUmPdf.Size = new System.Drawing.Size(121, 35);
            this.btnGerarUmPdf.TabIndex = 31;
            this.btnGerarUmPdf.Text = "Gerar um PDF";
            this.btnGerarUmPdf.UseVisualStyleBackColor = true;
            this.btnGerarUmPdf.Click += new System.EventHandler(this.btnGerarUmPdf_Click);
            // 
            // produto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(645, 668);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "produto";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "produto";
            this.Load += new System.EventHandler(this.produto_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private GroupBox groupBox1;
        private TextBox txtCa;
        private Label label5;
        private TextBox txtPcAquisicao;
        private Label label4;
        private TextBox txtCustoAquisicao;
        private Label label3;
        private TextBox txtCustoPedido;
        private Label label2;
        private TextBox txtNome;
        private Label label1;
        private GroupBox groupBox2;
        private Label label8;
        private ComboBox cboIdFornecedor;
        private Label label7;
        private ComboBox cboIdNivelServico;
        private Label label6;
        private ComboBox cboIdCategoria;
        private GroupBox groupBox3;
        private Button btnLimpar;
        private Button btnPesquisar;
        private Button btnAlterar;
        private Button btnSalvar;
        private TextBox txtDescricao;
        private Label label9;
        private Button btnFechar;
        private Button btnExcluir;
        private TextBox txtPcArmazenagem;
        private Label label12;
        private Label label11;
        private ComboBox cboStatus;
        private TextBox txtObs;
        private Label label10;
        private Label label13;
        private TextBox txtId;
        private ComboBox cboValorCat;
        private ComboBox cbValorFornecedor;
        private ComboBox cbValorNV;
        private Button btnExportarDados;
        private TextBox txtCodbarras;
        private Label label16;
        private TextBox txtDescricao2;
        private Label label15;
        private TextBox txtCodigo;
        private Label label14;
        private Button btnImportar;
        private Button btnParametros;
        private Button btnGerarPdf;
        private Button btnGerarUmPdf;
    }
}