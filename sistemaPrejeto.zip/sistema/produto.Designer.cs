﻿namespace sistema
{
    partial class produto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnGerarUmPdf = new System.Windows.Forms.Button();
            this.btnGerarPdf = new System.Windows.Forms.Button();
            this.btnParametros = new System.Windows.Forms.Button();
            this.btnImportar = new System.Windows.Forms.Button();
            this.btnExportarDados = new System.Windows.Forms.Button();
            this.btnFechar = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtDescricao2 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtCodbarras = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.cbValorNV = new System.Windows.Forms.ComboBox();
            this.cboStatus = new System.Windows.Forms.ComboBox();
            this.cbValorFornecedor = new System.Windows.Forms.ComboBox();
            this.txtObs = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.txtCodigo = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.txtDescricao = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.cboValorCat = new System.Windows.Forms.ComboBox();
            this.txtPcArmazenagem = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.txtCa = new System.Windows.Forms.TextBox();
            this.cboIdNivelServico = new System.Windows.Forms.ComboBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.txtPcAquisicao = new System.Windows.Forms.TextBox();
            this.cboIdFornecedor = new System.Windows.Forms.ComboBox();
            this.label25 = new System.Windows.Forms.Label();
            this.txtCustoAquisicao = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.txtCustoPedido = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.cboIdCategoria = new System.Windows.Forms.ComboBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.btnExcluir = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnPesquisar = new System.Windows.Forms.Button();
            this.btnAlterar = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label14 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // btnGerarUmPdf
            // 
            this.btnGerarUmPdf.Location = new System.Drawing.Point(317, 50);
            this.btnGerarUmPdf.Name = "btnGerarUmPdf";
            this.btnGerarUmPdf.Size = new System.Drawing.Size(121, 35);
            this.btnGerarUmPdf.TabIndex = 31;
            this.btnGerarUmPdf.Text = "Gerar um PDF";
            this.btnGerarUmPdf.UseVisualStyleBackColor = true;
            this.btnGerarUmPdf.Click += new System.EventHandler(this.btnGerarUmPdf_Click_1);
            // 
            // btnGerarPdf
            // 
            this.btnGerarPdf.Location = new System.Drawing.Point(444, 49);
            this.btnGerarPdf.Name = "btnGerarPdf";
            this.btnGerarPdf.Size = new System.Drawing.Size(99, 36);
            this.btnGerarPdf.TabIndex = 30;
            this.btnGerarPdf.Text = "Relatório";
            this.btnGerarPdf.UseVisualStyleBackColor = true;
            this.btnGerarPdf.Click += new System.EventHandler(this.btnGerarPdf_Click_1);
            // 
            // btnParametros
            // 
            this.btnParametros.Location = new System.Drawing.Point(549, 47);
            this.btnParametros.Name = "btnParametros";
            this.btnParametros.Size = new System.Drawing.Size(96, 36);
            this.btnParametros.TabIndex = 29;
            this.btnParametros.Text = "Parametros";
            this.btnParametros.UseVisualStyleBackColor = true;
            this.btnParametros.Click += new System.EventHandler(this.btnParametros_Click);
            // 
            // btnImportar
            // 
            this.btnImportar.Location = new System.Drawing.Point(9, 97);
            this.btnImportar.Name = "btnImportar";
            this.btnImportar.Size = new System.Drawing.Size(69, 26);
            this.btnImportar.TabIndex = 22;
            this.btnImportar.Text = "Importar";
            this.btnImportar.UseVisualStyleBackColor = true;
            this.btnImportar.Click += new System.EventHandler(this.btnImportar_Click);
            // 
            // btnExportarDados
            // 
            this.btnExportarDados.Location = new System.Drawing.Point(84, 95);
            this.btnExportarDados.Name = "btnExportarDados";
            this.btnExportarDados.Size = new System.Drawing.Size(96, 28);
            this.btnExportarDados.TabIndex = 22;
            this.btnExportarDados.Text = "Exportar Dados";
            this.btnExportarDados.UseVisualStyleBackColor = true;
            this.btnExportarDados.Click += new System.EventHandler(this.btnExportarDados_Click_1);
            // 
            // btnFechar
            // 
            this.btnFechar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnFechar.Image = global::sistema.Properties.Resources.sair;
            this.btnFechar.Location = new System.Drawing.Point(625, 29);
            this.btnFechar.Name = "btnFechar";
            this.btnFechar.Size = new System.Drawing.Size(39, 37);
            this.btnFechar.TabIndex = 5;
            this.btnFechar.UseVisualStyleBackColor = true;
            this.btnFechar.Click += new System.EventHandler(this.btnFechar_Click_1);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = global::sistema.Properties.Resources.Captura_de_tela_2024_06_02_010232;
            this.pictureBox1.Location = new System.Drawing.Point(3, 1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(687, 94);
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label2);
            this.groupBox4.Controls.Add(this.txtDescricao2);
            this.groupBox4.Controls.Add(this.label1);
            this.groupBox4.Controls.Add(this.txtCodbarras);
            this.groupBox4.Controls.Add(this.label17);
            this.groupBox4.Controls.Add(this.cbValorNV);
            this.groupBox4.Controls.Add(this.cboStatus);
            this.groupBox4.Controls.Add(this.cbValorFornecedor);
            this.groupBox4.Controls.Add(this.txtObs);
            this.groupBox4.Controls.Add(this.label18);
            this.groupBox4.Controls.Add(this.button1);
            this.groupBox4.Controls.Add(this.txtCodigo);
            this.groupBox4.Controls.Add(this.label19);
            this.groupBox4.Controls.Add(this.txtDescricao);
            this.groupBox4.Controls.Add(this.label20);
            this.groupBox4.Controls.Add(this.cboValorCat);
            this.groupBox4.Controls.Add(this.txtPcArmazenagem);
            this.groupBox4.Controls.Add(this.label21);
            this.groupBox4.Controls.Add(this.label22);
            this.groupBox4.Controls.Add(this.txtCa);
            this.groupBox4.Controls.Add(this.cboIdNivelServico);
            this.groupBox4.Controls.Add(this.label23);
            this.groupBox4.Controls.Add(this.label24);
            this.groupBox4.Controls.Add(this.txtPcAquisicao);
            this.groupBox4.Controls.Add(this.cboIdFornecedor);
            this.groupBox4.Controls.Add(this.label25);
            this.groupBox4.Controls.Add(this.txtCustoAquisicao);
            this.groupBox4.Controls.Add(this.label26);
            this.groupBox4.Controls.Add(this.txtCustoPedido);
            this.groupBox4.Controls.Add(this.label27);
            this.groupBox4.Controls.Add(this.txtNome);
            this.groupBox4.Controls.Add(this.label28);
            this.groupBox4.Controls.Add(this.label29);
            this.groupBox4.Controls.Add(this.cboIdCategoria);
            this.groupBox4.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.groupBox4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(48)))), ((int)(((byte)(65)))));
            this.groupBox4.Location = new System.Drawing.Point(3, 91);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(687, 380);
            this.groupBox4.TabIndex = 5;
            this.groupBox4.TabStop = false;
            this.groupBox4.Enter += new System.EventHandler(this.groupBox4_Enter);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(399, 296);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(196, 16);
            this.label2.TabIndex = 25;
            this.label2.Text = "Descrição: Código de barras";
            // 
            // txtDescricao2
            // 
            this.txtDescricao2.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtDescricao2.Location = new System.Drawing.Point(399, 315);
            this.txtDescricao2.Multiline = true;
            this.txtDescricao2.Name = "txtDescricao2";
            this.txtDescricao2.Size = new System.Drawing.Size(262, 43);
            this.txtDescricao2.TabIndex = 24;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(6, 296);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(123, 16);
            this.label1.TabIndex = 23;
            this.label1.Text = "Código de barras";
            // 
            // txtCodbarras
            // 
            this.txtCodbarras.Location = new System.Drawing.Point(9, 315);
            this.txtCodbarras.Name = "txtCodbarras";
            this.txtCodbarras.Size = new System.Drawing.Size(335, 29);
            this.txtCodbarras.TabIndex = 22;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label17.Location = new System.Drawing.Point(590, 162);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(45, 16);
            this.label17.TabIndex = 18;
            this.label17.Text = "Status";
            // 
            // cbValorNV
            // 
            this.cbValorNV.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.cbValorNV.FormattingEnabled = true;
            this.cbValorNV.Location = new System.Drawing.Point(590, 132);
            this.cbValorNV.Name = "cbValorNV";
            this.cbValorNV.Size = new System.Drawing.Size(92, 24);
            this.cbValorNV.TabIndex = 20;
            this.cbValorNV.Visible = false;
            this.cbValorNV.SelectedIndexChanged += new System.EventHandler(this.cbValorNV_SelectedIndexChanged_1);
            // 
            // cboStatus
            // 
            this.cboStatus.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.cboStatus.FormattingEnabled = true;
            this.cboStatus.Items.AddRange(new object[] {
            "ATIVO\t",
            "INATIVO"});
            this.cboStatus.Location = new System.Drawing.Point(590, 185);
            this.cboStatus.Name = "cboStatus";
            this.cboStatus.Size = new System.Drawing.Size(86, 24);
            this.cboStatus.TabIndex = 10;
            // 
            // cbValorFornecedor
            // 
            this.cbValorFornecedor.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.cbValorFornecedor.FormattingEnabled = true;
            this.cbValorFornecedor.Location = new System.Drawing.Point(596, 39);
            this.cbValorFornecedor.Name = "cbValorFornecedor";
            this.cbValorFornecedor.Size = new System.Drawing.Size(86, 24);
            this.cbValorFornecedor.TabIndex = 21;
            this.cbValorFornecedor.Visible = false;
            this.cbValorFornecedor.SelectedIndexChanged += new System.EventHandler(this.cbValorFornecedor_SelectedIndexChanged_1);
            // 
            // txtObs
            // 
            this.txtObs.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtObs.Location = new System.Drawing.Point(355, 185);
            this.txtObs.Multiline = true;
            this.txtObs.Name = "txtObs";
            this.txtObs.Size = new System.Drawing.Size(229, 93);
            this.txtObs.TabIndex = 11;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label18.Location = new System.Drawing.Point(355, 166);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(92, 16);
            this.label18.TabIndex = 15;
            this.label18.Text = "Observações";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(48)))), ((int)(((byte)(65)))));
            this.button1.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(616, 245);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(60, 33);
            this.button1.TabIndex = 0;
            this.button1.Text = "Salvar";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // txtCodigo
            // 
            this.txtCodigo.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtCodigo.Location = new System.Drawing.Point(648, 13);
            this.txtCodigo.Name = "txtCodigo";
            this.txtCodigo.Size = new System.Drawing.Size(34, 23);
            this.txtCodigo.TabIndex = 13;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label19.Location = new System.Drawing.Point(622, 16);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(20, 16);
            this.label19.TabIndex = 12;
            this.label19.Text = "ID";
            // 
            // txtDescricao
            // 
            this.txtDescricao.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtDescricao.Location = new System.Drawing.Point(6, 185);
            this.txtDescricao.Multiline = true;
            this.txtDescricao.Name = "txtDescricao";
            this.txtDescricao.Size = new System.Drawing.Size(341, 93);
            this.txtDescricao.TabIndex = 11;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label20.Location = new System.Drawing.Point(6, 166);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(152, 16);
            this.label20.TabIndex = 10;
            this.label20.Text = "Descrição do produto:";
            // 
            // cboValorCat
            // 
            this.cboValorCat.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.cboValorCat.FormattingEnabled = true;
            this.cboValorCat.Location = new System.Drawing.Point(255, 39);
            this.cboValorCat.Name = "cboValorCat";
            this.cboValorCat.Size = new System.Drawing.Size(92, 24);
            this.cboValorCat.TabIndex = 19;
            this.cboValorCat.Visible = false;
            this.cboValorCat.SelectedIndexChanged += new System.EventHandler(this.cboValorCat_SelectedIndexChanged_1);
            // 
            // txtPcArmazenagem
            // 
            this.txtPcArmazenagem.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtPcArmazenagem.Location = new System.Drawing.Point(269, 132);
            this.txtPcArmazenagem.Name = "txtPcArmazenagem";
            this.txtPcArmazenagem.Size = new System.Drawing.Size(78, 23);
            this.txtPcArmazenagem.TabIndex = 6;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label21.Location = new System.Drawing.Point(6, 135);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(258, 16);
            this.label21.TabIndex = 10;
            this.label21.Text = "Percentual de Custo de Armazenagem";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label22.Location = new System.Drawing.Point(355, 135);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(112, 16);
            this.label22.TabIndex = 12;
            this.label22.Text = "Nivel de Serviço";
            // 
            // txtCa
            // 
            this.txtCa.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtCa.Location = new System.Drawing.Point(523, 98);
            this.txtCa.Name = "txtCa";
            this.txtCa.Size = new System.Drawing.Size(159, 23);
            this.txtCa.TabIndex = 5;
            // 
            // cboIdNivelServico
            // 
            this.cboIdNivelServico.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.cboIdNivelServico.FormattingEnabled = true;
            this.cboIdNivelServico.Location = new System.Drawing.Point(473, 131);
            this.cboIdNivelServico.Name = "cboIdNivelServico";
            this.cboIdNivelServico.Size = new System.Drawing.Size(111, 24);
            this.cboIdNivelServico.TabIndex = 8;
            this.cboIdNivelServico.TabStop = false;
            this.cboIdNivelServico.SelectedIndexChanged += new System.EventHandler(this.cboIdNivelServico_SelectedIndexChanged_1);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label23.Location = new System.Drawing.Point(353, 103);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(164, 16);
            this.label23.TabIndex = 8;
            this.label23.Text = "Custo de Armazenagem";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label24.Location = new System.Drawing.Point(353, 42);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(80, 16);
            this.label24.TabIndex = 14;
            this.label24.Text = "Fornecedor";
            // 
            // txtPcAquisicao
            // 
            this.txtPcAquisicao.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtPcAquisicao.Location = new System.Drawing.Point(240, 100);
            this.txtPcAquisicao.Name = "txtPcAquisicao";
            this.txtPcAquisicao.Size = new System.Drawing.Size(107, 23);
            this.txtPcAquisicao.TabIndex = 4;
            // 
            // cboIdFornecedor
            // 
            this.cboIdFornecedor.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.cboIdFornecedor.FormattingEnabled = true;
            this.cboIdFornecedor.Location = new System.Drawing.Point(439, 39);
            this.cboIdFornecedor.Name = "cboIdFornecedor";
            this.cboIdFornecedor.Size = new System.Drawing.Size(151, 24);
            this.cboIdFornecedor.TabIndex = 9;
            this.cboIdFornecedor.SelectedIndexChanged += new System.EventHandler(this.cboIdFornecedor_SelectedIndexChanged_1);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label25.Location = new System.Drawing.Point(6, 107);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(228, 16);
            this.label25.TabIndex = 6;
            this.label25.Text = "Percentual de Custo de Aquisição";
            // 
            // txtCustoAquisicao
            // 
            this.txtCustoAquisicao.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtCustoAquisicao.Location = new System.Drawing.Point(568, 69);
            this.txtCustoAquisicao.Name = "txtCustoAquisicao";
            this.txtCustoAquisicao.Size = new System.Drawing.Size(114, 23);
            this.txtCustoAquisicao.TabIndex = 3;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label26.Location = new System.Drawing.Point(353, 72);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(209, 16);
            this.label26.TabIndex = 4;
            this.label26.Text = "Custo de aquisição do produto";
            // 
            // txtCustoPedido
            // 
            this.txtCustoPedido.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtCustoPedido.Location = new System.Drawing.Point(199, 69);
            this.txtCustoPedido.Name = "txtCustoPedido";
            this.txtCustoPedido.Size = new System.Drawing.Size(148, 23);
            this.txtCustoPedido.TabIndex = 2;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label27.Location = new System.Drawing.Point(6, 72);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(191, 16);
            this.label27.TabIndex = 2;
            this.label27.Text = "Custo de pedido do produto";
            // 
            // txtNome
            // 
            this.txtNome.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtNome.Location = new System.Drawing.Point(133, 10);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(484, 23);
            this.txtNome.TabIndex = 1;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label28.Location = new System.Drawing.Point(4, 47);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(149, 16);
            this.label28.TabIndex = 10;
            this.label28.Text = "Categoria do produto";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label29.Location = new System.Drawing.Point(6, 13);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(121, 16);
            this.label29.TabIndex = 0;
            this.label29.Text = "Nome do produto";
            // 
            // cboIdCategoria
            // 
            this.cboIdCategoria.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.cboIdCategoria.FormattingEnabled = true;
            this.cboIdCategoria.Location = new System.Drawing.Point(159, 39);
            this.cboIdCategoria.Name = "cboIdCategoria";
            this.cboIdCategoria.Size = new System.Drawing.Size(90, 24);
            this.cboIdCategoria.TabIndex = 7;
            this.cboIdCategoria.SelectedIndexChanged += new System.EventHandler(this.cboIdCategoria_SelectedIndexChanged_1);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.btnParametros);
            this.groupBox5.Controls.Add(this.btnGerarPdf);
            this.groupBox5.Controls.Add(this.btnGerarUmPdf);
            this.groupBox5.Controls.Add(this.label30);
            this.groupBox5.Controls.Add(this.label31);
            this.groupBox5.Controls.Add(this.btnExcluir);
            this.groupBox5.Controls.Add(this.btnExportarDados);
            this.groupBox5.Controls.Add(this.btnImportar);
            this.groupBox5.Controls.Add(this.btnLimpar);
            this.groupBox5.Controls.Add(this.btnPesquisar);
            this.groupBox5.Controls.Add(this.btnAlterar);
            this.groupBox5.Location = new System.Drawing.Point(3, 459);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(687, 134);
            this.groupBox5.TabIndex = 6;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = ";";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label30.Location = new System.Drawing.Point(6, 34);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(445, 17);
            this.label30.TabIndex = 26;
            this.label30.Text = "Faça pesquisas, limpe, exclua ou altere os dados do seu formulário.";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.BackColor = System.Drawing.SystemColors.Control;
            this.label31.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label31.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(48)))), ((int)(((byte)(65)))));
            this.label31.Location = new System.Drawing.Point(6, 15);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(99, 19);
            this.label31.TabIndex = 25;
            this.label31.Text = "Mais ações:";
            // 
            // btnExcluir
            // 
            this.btnExcluir.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnExcluir.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(48)))), ((int)(((byte)(65)))));
            this.btnExcluir.Location = new System.Drawing.Point(242, 54);
            this.btnExcluir.Name = "btnExcluir";
            this.btnExcluir.Size = new System.Drawing.Size(69, 29);
            this.btnExcluir.TabIndex = 4;
            this.btnExcluir.Text = "Excluir";
            this.btnExcluir.UseVisualStyleBackColor = true;
            this.btnExcluir.Click += new System.EventHandler(this.btnExcluir_Click_1);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnLimpar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(48)))), ((int)(((byte)(65)))));
            this.btnLimpar.Location = new System.Drawing.Point(167, 54);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(69, 29);
            this.btnLimpar.TabIndex = 3;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click_1);
            // 
            // btnPesquisar
            // 
            this.btnPesquisar.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnPesquisar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(48)))), ((int)(((byte)(65)))));
            this.btnPesquisar.Location = new System.Drawing.Point(84, 54);
            this.btnPesquisar.Name = "btnPesquisar";
            this.btnPesquisar.Size = new System.Drawing.Size(77, 29);
            this.btnPesquisar.TabIndex = 2;
            this.btnPesquisar.Text = "Pesquisar";
            this.btnPesquisar.UseVisualStyleBackColor = true;
            this.btnPesquisar.Click += new System.EventHandler(this.btnPesquisar_Click_1);
            // 
            // btnAlterar
            // 
            this.btnAlterar.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnAlterar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(48)))), ((int)(((byte)(65)))));
            this.btnAlterar.Location = new System.Drawing.Point(9, 54);
            this.btnAlterar.Name = "btnAlterar";
            this.btnAlterar.Size = new System.Drawing.Size(69, 29);
            this.btnAlterar.TabIndex = 1;
            this.btnAlterar.Text = "Alterar";
            this.btnAlterar.UseVisualStyleBackColor = true;
            this.btnAlterar.Click += new System.EventHandler(this.btnAlterar_Click_1);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::sistema.Properties.Resources.RODAPÉ;
            this.pictureBox2.Location = new System.Drawing.Point(3, 599);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(687, 63);
            this.pictureBox2.TabIndex = 7;
            this.pictureBox2.TabStop = false;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(48)))), ((int)(((byte)(65)))));
            this.label14.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(258, 20);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(89, 23);
            this.label14.TabIndex = 33;
            this.label14.Text = "Produtos";
            // 
            // produto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(691, 663);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.btnFechar);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "produto";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "produto";
            this.Load += new System.EventHandler(this.produto_Load_1);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Button btnFechar;
        private Button btnExportarDados;
        private Button btnImportar;
        private Button btnParametros;
        private Button btnGerarPdf;
        private Button btnGerarUmPdf;
        private PictureBox pictureBox1;
        private GroupBox groupBox4;
        private Label label17;
        private ComboBox cbValorNV;
        private ComboBox cboStatus;
        private ComboBox cbValorFornecedor;
        private TextBox txtObs;
        private Label label18;
        private Button button1;
        private TextBox txtCodigo;
        private Label label19;
        private TextBox txtDescricao;
        private Label label20;
        private ComboBox cboValorCat;
        private TextBox txtPcArmazenagem;
        private Label label21;
        private Label label22;
        private TextBox txtCa;
        private ComboBox cboIdNivelServico;
        private Label label23;
        private Label label24;
        private TextBox txtPcAquisicao;
        private ComboBox cboIdFornecedor;
        private Label label25;
        private TextBox txtCustoAquisicao;
        private Label label26;
        private TextBox txtCustoPedido;
        private Label label27;
        private TextBox txtNome;
        private Label label28;
        private Label label29;
        private ComboBox cboIdCategoria;
        private GroupBox groupBox5;
        private Label label30;
        private Label label31;
        private Button btnExcluir;
        private Button btnLimpar;
        private Button btnPesquisar;
        private Button btnAlterar;
        private PictureBox pictureBox2;
        private Label label14;
        private Label label1;
        private TextBox txtCodbarras;
        private TextBox txtDescricao2;
        private Label label2;
    }
}