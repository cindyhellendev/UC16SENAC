using System;
using System.Data;
using System.Data.SqlClient;




namespace sistema
{
    public partial class FrmNiveldeServico : Form
    {
        string stringConexao = "" + 
            "Data Source=10.37.45.37;" + 
            "Initial Catalog=sistema;" + 
            "User ID=sa;" + 
            "Password=123456";

        private void TestarConexao()

        {
            SqlConnection conn = new SqlConnection(stringConexao);

            try
            {
                conn.Open();
                conn.Close();

            }
            catch (Exception ex)
            {

                MessageBox.Show("Erro: " + ex.ToString());
                Application.Exit();
            }
        }

        public FrmNiveldeServico()
        {
            InitializeComponent();

        }



        private void FrmNiveldeServico_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtID.Text = "";
            txtNome.Text = "";
            txtFatorseranca.Text = "";
            txtObs.Text = "";

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        double num1;
        double num2;

        private bool ValidarDados()
        {
            if (!double.TryParse(txtNome.Text, out num1))
            {
                MessageBox.Show("Erro,campos devem ser numerico", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtNome.Text = "";
                txtNome.Focus();
                return false;
            }

            if (!double.TryParse(txtFatorseranca.Text, out num1))
            {
                MessageBox.Show("Erro,campos devem ser numerico", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtFatorseranca.Text = "";
                txtFatorseranca.Focus();
                return false;
            }


            if (txtNome.Text == "" )
            {
                MessageBox.Show("Erro, campo deve ser preenchido", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtNome.Text = "";
                txtNome.Focus();
                return false;
            }

            if (txtFatorseranca.Text == "")
            {
                MessageBox.Show("Erro, campo deve ser preenchido", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtFatorseranca.Text = "";
                txtFatorseranca.Focus();
                return false;
            }

            return true;
           

        }

            private void btnSalvar_Click(object sender, EventArgs e)
            {
            if (ValidarDados() == false)
            {
                return;
            }

            

            string sql = "insert into nivel_de_servico" +
                "(" +
                "percentual_nivel_servico," +
                "fator_de_seguranca_nivel_servico," +
                "obs_nivel_de_servico," +
                "status_nivel_de_servico " +
                ")" +
                "values" +
                "(" +
                "'" + txtNome.Text + "'," +
                "'" + txtFatorseranca.Text + "', " +
                "'" + txtObs.Text + "'," +
                "'" + cboStatus.Text + "') " +
                "select SCOPE_IDENTITY()";



             /* "'" + txtNome.Text + "'," +
             "'" + txtFatorseranca.Text + "'," +
             "'" + txtObs.Text +
             + "select SCOPE_IDENTITY()";*/


             SqlConnection conn = new SqlConnection(stringConexao);
             SqlCommand cmd = new SqlCommand(sql, conn);
             cmd.CommandType = CommandType.Text;
             SqlDataReader leitura;
             conn.Open();

               try 
               {
                 leitura = cmd.ExecuteReader();
                 
                if (leitura.Read())
                {
                    MessageBox.Show("Cadastro Realizado com Sucesso!");
                    btnLimpar.PerformClick();
                    txtID.Text = leitura[0].ToString();
                    btnPesquisar.PerformClick();   
                }
               }
               catch(Exception ex)
               {
                    MessageBox.Show("Erro: " + ex.ToString());
               } 
               finally
               {
                conn.Close();               
               }

            }

            private void btnAlterar_Click(object sender, EventArgs e)
            {
                      
            }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {
           

            string sql = "select * from nivel_de_servico where id_nivel_servico =" + txtID.Text; 

            SqlConnection conexao = new SqlConnection(stringConexao);
            SqlCommand cmd = new SqlCommand(sql, conexao);
            cmd.CommandType = CommandType.Text;
            SqlDataReader reader;
            conexao.Open();

            try
            {
                reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    txtID.Text = reader[0].ToString();
                    txtNome.Text = reader[1].ToString();
                    txtFatorseranca.Text = reader[2].ToString();    
                    txtObs.Text = reader[3].ToString(); 
                    cboStatus.Text = reader[4].ToString();
                }
                else
                {
                    MessageBox.Show("C�digo de usu�rio inexistente!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                conexao.Close();
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            int n;
            if (!int.TryParse(txtID.Text, out n))
            {
                MessageBox.Show("Erro, C�digo deve ser preenchido", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtID.Text = "";
                txtID.Focus();
                return;
            }
            MessageBox.Show("Dados validados com sucesso para o EXCLUIR", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);

            string sql = "delete from nivel_de_servico where id_nivel_servico = " + txtID.Text;

            SqlConnection conexao = new SqlConnection(stringConexao);
            SqlCommand cmd = new SqlCommand(sql, conexao);
            cmd.CommandType = CommandType.Text;

            try
            {
                conexao.Open();

                int i = cmd.ExecuteNonQuery();
                if (i == 1)
                {
                    MessageBox.Show("Dados excluidos com sucesso");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                conexao.Close();
            }
        }
        private void btnAlterar_Click_1(object sender, EventArgs e)
        {
            int n;
            if (!int.TryParse(txtID.Text, out n))
            {
                MessageBox.Show("Erro, C�digo deve ser preenchido", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtID.Text = "";
                txtID.Focus();
                return;
            }
            if (ValidarDados())
            {
                MessageBox.Show("Dados validados com sucesso para o ALTERAR", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            string sql = "update nivel_de_servico set percentual_nivel_servico='" + txtNome.Text + "'," +
                "fator_de_seguranca_nivel_servico='" + txtFatorseranca.Text + "'," +
                "obs_nivel_de_servico='" + txtObs.Text + "'," +
                "status_nivel_de_servico='" + cboStatus.Text;

            SqlConnection conexao = new SqlConnection(sql);
            SqlCommand cmd = new SqlCommand(sql, conexao);
            cmd.CommandType = CommandType.Text;

            try
            {
                conexao.Open();

                int i = cmd.ExecuteNonQuery();
                if (i == 1)
                {
                    MessageBox.Show("Dados alterados com sucesso!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                conexao.Close();
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void txtID_TextChanged(object sender, EventArgs e)
        {

        }
    }
}