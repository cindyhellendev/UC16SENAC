using System.Data;
using System.Data.SqlClient;

namespace sistema
{
    public partial class frmCategoria : Form
    {
        public frmCategoria()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            TestarConexao();
            if (av != "")
            {
                txtCodigo.Text = av;
                av = "";
            }
        }

        string conexao = "Data Source= 10.37.45.37;" +
                         "Initial Catalog= sistema;" +
                         "User ID=sa;" +
                         "Password=123456";

        public static string av;


        private void TestarConexao()
        {
            SqlConnection conn = new SqlConnection(conexao);

            try
            {
                conn.Open();
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro: " + ex.ToString(), "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Application.Exit();
            }

        }



        private void btoSalvar_Click(object sender, EventArgs e)
        {

            if (validar() == false)
            {
                return;
            }

            string sql = "insert into categoria ( nome_categoria, descri��o_categoria,obs_categoria, id_produto)" +
              "values" +
             "('" + txtNome.Text + "', '" + txtDescricao.Text + "', '" + txtObs.Text + "') " +
             "select SCOPE_IDENTITY()";


            SqlConnection conn = new SqlConnection(conexao);
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.CommandType = CommandType.Text;
            SqlDataReader leitura;
            conn.Open();

            try
            {
                leitura = cmd.ExecuteReader();
                if (leitura.Read())
                {
                    MessageBox.Show("Cadastro realizado com sucesso", "C�digo Gerado: " + leitura[0].ToString(), MessageBoxButtons.OK, MessageBoxIcon.Information);
                    btnLimpar.PerformClick();
                    txtCodigo.Text = leitura[0].ToString();
                    btnPesquisar.PerformClick();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                conn.Close();
            }

        }

        private void btoPesquisar_Click(object sender, EventArgs e)
        {
            if (txtCodigo.Text == "")
            {
                MessageBox.Show("Erro: O campo id deve ser preenchido", "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string sql = "select * from  categoria where id_categoria = " + txtCodigo.Text;

            SqlConnection conn = new SqlConnection(conexao);
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.CommandType = CommandType.Text;
            SqlDataReader reader;
            conn.Open();

            try
            {
                reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    txtCodigo.Text = reader[0].ToString();
                    txtNome.Text = reader[1].ToString();
                    txtDescricao.Text = reader[2].ToString();
                    txtObs.Text = reader[3].ToString();
                    cboStatus.Text = reader[4].ToString();
                }
                else
                {
                    MessageBox.Show("C�digo do usu�rio inexistente!", "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                conn.Close();
            }
        }

        private void btoAlterar_Click(object sender, EventArgs e)
        {
            if (validar() == false)
            {
                return;
            }

            string sql = "update categoria set " +
                "nome_categoria = '" + txtNome.Text + "'," +
                "descri��o_categoria = '" + txtDescricao.Text + "'," +
                "obs_categoria = '" + txtObs.Text + "'," +
                "status_categoria = '" + cboStatus.Text + "' where id_categoria =" + txtCodigo.Text;

            SqlConnection conn = new SqlConnection(conexao);
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.CommandType = CommandType.Text;
            conn.Open();

            try
            {
                int i = cmd.ExecuteNonQuery();
                if (i == 1)
                {
                    MessageBox.Show("Dados alterados com sucesso", "SECESSO", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                conn.Close();
            }
        }

        private void btoExcluir_Click(object sender, EventArgs e)
        {
            if (txtCodigo.Text == "")
            {
                MessageBox.Show("Erro: O campo id deve ser preenchido", "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string sql = "delete from categoria WHERE id_categoria = " + txtCodigo.Text;

            SqlConnection conn = new SqlConnection(conexao);
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.CommandType = CommandType.Text;
            conn.Open();
            try
            {
                int i = cmd.ExecuteNonQuery();
                if (i == 1)
                {
                    MessageBox.Show("Dados excluidos com sucesso", "SECESSO", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    btnLimpar.PerformClick();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            finally
            {
                conn.Close();
            }
        }

        private void btoLimpar_Click(object sender, EventArgs e)
        {
            txtCodigo.Text = "";
            txtNome.Text = "";
            txtDescricao.Text = "";
            txtObs.Text = "";
            cboStatus.Items.Clear();
        }

        private bool validar()
        {
            if (txtNome.Text == "")
            {
                MessageBox.Show("Erro: O campo nome deve ser preenchido", "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            else if (txtDescricao.Text == "")
            {
                MessageBox.Show("Erro: O campo descri��o deve ser preenchido", "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            return true;
        }

        private void btoSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }



        private void btnSalvar_Click(object sender, EventArgs e)
        {
            if (validar() == false)
            {
                return;
            }

            string sql = "insert into categoria ( nome_categoria, descri��o_categoria,obs_categoria, id_produto)" +
              "values" +
             "('" + txtNome.Text + "', '" + txtDescricao.Text + "', '" + txtObs.Text + "') " +
             "select SCOPE_IDENTITY()";


            SqlConnection conn = new SqlConnection(conexao);
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.CommandType = CommandType.Text;
            SqlDataReader leitura;
            conn.Open();

            try
            {
                leitura = cmd.ExecuteReader();
                if (leitura.Read())
                {
                    MessageBox.Show("Cadastro realizado com sucesso", "C�digo Gerado: " + leitura[0].ToString(), MessageBoxButtons.OK, MessageBoxIcon.Information);
                    btnLimpar.PerformClick();
                    txtCodigo.Text = leitura[0].ToString();
                    btnPesquisar.PerformClick();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                conn.Close();
            }
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
          

            string sql = "update categoria set " +
                "nome_categoria = '" + txtNome.Text + "'," +
                "descri��o_categoria = '" + txtDescricao.Text + "'," +
                "obs_categoria = '" + txtObs.Text + "'," +
                "status_categoria = '" + cboStatus.Text + "' where id_categoria =" + txtCodigo.Text;

            SqlConnection conn = new SqlConnection(conexao);
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.CommandType = CommandType.Text;
            conn.Open();

            try
            {
                int i = cmd.ExecuteNonQuery();
                if (i == 1)
                {
                    MessageBox.Show("Dados alterados com sucesso", "SECESSO", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                conn.Close();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtCodigo.Text = "";
            txtNome.Text = "";
            txtDescricao.Text = "";
            txtObs.Text = "";
            cboStatus.Items.Clear();
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (txtCodigo.Text == "")
            {
                MessageBox.Show("Erro: O campo id deve ser preenchido", "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string sql = "delete from categoria WHERE id_categoria = " + txtCodigo.Text;

            SqlConnection conn = new SqlConnection(conexao);
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.CommandType = CommandType.Text;
            conn.Open();
            try
            {
                int i = cmd.ExecuteNonQuery();
                if (i == 1)
                {
                    MessageBox.Show("Dados excluidos com sucesso", "SECESSO", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    btnLimpar.PerformClick();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            finally
            {
                conn.Close();
            }
        }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {
            if (txtCodigo.Text == "")
            {
                MessageBox.Show("Erro: O campo id deve ser preenchido", "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string sql = "select * from  categoria where id_categoria = " + txtCodigo.Text;

            SqlConnection conn = new SqlConnection(conexao);
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.CommandType = CommandType.Text;
            SqlDataReader reader;
            conn.Open();

            try
            {
                reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    txtCodigo.Text = reader[0].ToString();
                    txtNome.Text = reader[1].ToString();
                    txtDescricao.Text = reader[2].ToString();
                    txtObs.Text = reader[3].ToString();
                    cboStatus.Text = reader[4].ToString();
                }
                else
                {
                    MessageBox.Show("C�digo do usu�rio inexistente!", "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                conn.Close();
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmCategoria_Load(object sender, EventArgs e)
        {

        }
    }

}