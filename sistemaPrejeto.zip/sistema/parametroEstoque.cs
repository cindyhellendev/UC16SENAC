﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Data;
using System.Data.SqlClient;

namespace sistema
{
    public partial class parametroEstoque : Form
    {
        public parametroEstoque()
        {
            InitializeComponent();
        }

        public string EstoqueSeguranca
        {
            get { return txtEstoqueSeguranca.Text; }
            set { txtEstoqueSeguranca.Text = value; }
        }

        string strConexao = "" +
                "Data Source=localhost;" +
                "Initial Catalog=sistema;" +
                "User ID=sa;" +
                "Password=123456";


        private void conexao()
        {
            SqlConnection conn = new SqlConnection(strConexao);

            try
            {
                conn.Open();
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro " + ex.ToString());
                Application.Exit();
            }
        }

        

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            if (ValidarDados() == false)
            {
                return;
            }

            string sql = "insert into parametro_de_estoque" +
                 "(" +
                    "id_produto, " +
                     "estoque_de_seguranca_parametro_de_estoque," +
                     "estoque_maximo_parametro_de_estoque," +
                     "estoque_medio_parametro_de_estoque," +
                     "ponto_de_pedido_parametro_de_estoque," +
                     "intervalo_entre_pedido_parametro_de_estoque," +
                     "intervalo_de_tempo_parametro_de_estoque," +
                     "lote_economico_de_compra_parametro_de_estoque," +
                     "obs_parametro_de_estoque," +
                     "status_parametro_de_estoque" +
                 ")" +
                 "values" +
                 "(" +
                     "'" + cbValorProduto.Text + "', " +
                     "'" + txtEstoqueSeguranca.Text + "'," +
                     "'" + txtEstoqueMaximo.Text + "'," +
                     "'" + txtEstoqueMedio.Text + "'," +
                     "'" + txtPontoPedido.Text + "'," +
                     "'" + txtIntervalorPedido.Text + "'," +
                     "'" + txtLec.Text + "'," +
                     "'" + txtObs.Text + "'," +
                     "'" + cboStatus.Text + "'" +
                 ")select SCOPE_IDENTITY()";

            SqlConnection conexao = new SqlConnection(strConexao);
            SqlCommand cmd = new SqlCommand(sql, conexao);
            cmd.CommandType = CommandType.Text;
            SqlDataReader reader;
            conexao.Open();

            try
            {
                reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    MessageBox.Show("Cadastro realizado com sucesso");

                    btnLimpar.PerformClick();
                    txtId.Text = reader[0].ToString();
                    btnPesquisar.PerformClick();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());

            }
            finally
            {
                conexao.Close();
            }
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {
    
            string sql = "select * from parametro_de_estoque where id_parametro =" + txtId.Text;

            SqlConnection conexao = new SqlConnection(strConexao);
            SqlCommand cmd = new SqlCommand(sql, conexao);
            cmd.CommandType = CommandType.Text;
            SqlDataReader reader;
            conexao.Open();

            try
            {
                reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    txtId.Text = reader[0].ToString();
                    cboIdProduto.Text = reader[1].ToString();
                    txtEstoqueSeguranca.Text = reader[2].ToString();
                    txtEstoqueMaximo.Text = reader[3].ToString();
                    txtEstoqueMedio.Text = reader[4].ToString();
                    txtPontoPedido.Text = reader[5].ToString();
                    txtIntervalorPedido.Text = reader[6].ToString();
                    txtLec.Text = reader[7].ToString();

                    txtObs.Text = reader[8].ToString();
                    cboStatus.Text = reader[9].ToString();
                    
                }
                else
                {
                    MessageBox.Show("Código do usuario inexistente!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                conexao.Close();
            }

        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            string sql = "delete from fornecedor where id_fornecedor = " + txtId.Text;
            SqlConnection conn = new SqlConnection(strConexao);
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.CommandType = CommandType.Text;

            try
            {
                conn.Open();

                int i = cmd.ExecuteNonQuery();
                if (i > 0)
                {
                    MessageBox.Show("Cadastro excluido sucesso");
                    btnLimpar.PerformClick();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro: " + ex.ToString);

            }
            finally
            {
                conn.Close();
            }
        }

        //private void parametroEstoque(object sender, EventArgs e)
        private void Form1_Load(object sender, EventArgs e)
        //private void parametroEstoque(object sender, EventArgs e)
        {
            conexao();
            CarregarCombo();

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtId.Text = "";
            cboIdProduto.Text = "";
            txtEstoqueSeguranca.Text = "";
            txtEstoqueMaximo.Text = "";
            txtEstoqueMedio.Text = "";
            txtIntervalorPedido.Text = "";
            txtLec.Text = "";
            txtObs.Text = "";
            cboStatus.Text = "";
            txtPontoPedido.Text = "";


        }

        private void btnExcluir_Click_1(object sender, EventArgs e)
        {
            string sql = "delete from parametro_de_estoque where id_parametro =" + txtId.Text;
            SqlConnection conn = new SqlConnection(strConexao);
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.CommandType = CommandType.Text;

            try
            {
                conn.Open();

                int i = cmd.ExecuteNonQuery();
                if (i > 0)
                {
                    MessageBox.Show("Cadastro excluido sucesso");
                    btnLimpar.PerformClick();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro: " + ex.ToString);

            }
            finally
            {
                conn.Close();
            }
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
           

            string sql = "update parametro_de_estoque set " +
               "id_produto = '" + cbValorProduto.Text + "', " +
               "estoque_de_seguranca_parametro_de_estoque = '" + txtEstoqueSeguranca.Text + "'," +
               "estoque_maximo_parametro_de_estoque = '" + txtEstoqueMaximo.Text + "', " +
               "estoque_medio_parametro_de_estoque = '" + txtEstoqueMedio.Text + "', " +
               "ponto_de_pedido_parametro_de_estoque = '" + txtPontoPedido.Text + "', " +
               "intervalo_entre_pedido_parametro_de_estoque = '" + txtLec.Text + "', " +
               "intervalo_de_tempo_parametro_de_estoque = '" + txtIntervalorPedido.Text + "', " +
               "obs_parametro_de_estoque = '" + txtObs.Text + "', " +
               "status_parametro_de_estoque = '" + txtObs.Text + "' " +
               "where id_parametro = " + txtId.Text;


            SqlConnection conn = new SqlConnection(strConexao);
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.CommandType = CommandType.Text;

            try
            {
                conn.Open();

                int i = cmd.ExecuteNonQuery();
                if (i == 1)
                {
                    MessageBox.Show("Alteração feita com sucesso");

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro: " + ex.ToString());
            }
            finally
            {
                conn.Close();
            }
        }

        void CarregarCombo()
        {
            string sql = "select id_produto, nome_produto from produto";

            SqlConnection conexao = new SqlConnection(strConexao);
            SqlCommand cmd = new SqlCommand(sql, conexao);
            cmd.CommandType = CommandType.Text;
            SqlDataReader reader;

            DataTable tabela = new DataTable();

            conexao.Open();

            try
            {
                reader = cmd.ExecuteReader();

                tabela.Load(reader);
                cbValorProduto.DisplayMember = "id_produto";
                cbValorProduto.DataSource = tabela;

                cboIdProduto.DisplayMember = "nome_produto";
                cboIdProduto.DataSource = tabela;


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                Application.Exit();

            }
            finally
            {
                conexao.Close();
            }
        }


        int n1;
        private bool ValidarDados()
        {
            if (int.TryParse(txtEstoqueSeguranca.Text, out n1) == false)
            {
                MessageBox.Show("Campo deve ser numerico!");
                txtEstoqueSeguranca.Focus();
                txtEstoqueSeguranca.Text = "";

                return false;
            }

            if (txtEstoqueSeguranca.Text == "")
            {
                MessageBox.Show("Campo deve ser preenchido");
                return false;
            }

            ////////////////////////////////////////////////////////////////////////////////////
            ///

            if (int.TryParse(txtEstoqueMaximo.Text, out n1) == false)
            {
                MessageBox.Show("Campo deve ser numerico!");
                txtEstoqueMaximo.Focus();
                txtEstoqueMaximo.Text = "";

                return false;
            }

            if (txtEstoqueMaximo.Text == "")
            {
                MessageBox.Show("Campo deve ser preenchido");
                return false;
            }

            ////////////////////////////////////////////////////////////////////////////////////
            ///

            if (int.TryParse(txtEstoqueMedio.Text, out n1) == false)
            {
                MessageBox.Show("Campo deve ser numerico!");
                txtEstoqueMedio.Focus();
                txtEstoqueMedio.Text = "";

                return false;
            }

            if (txtEstoqueMedio.Text == "")
            {
                MessageBox.Show("Campo deve ser preenchido");
                return false;
            }

            ////////////////////////////////////////////////////////////////////////////////////
            ///

            if (int.TryParse(txtPontoPedido.Text, out n1) == false)
            {
                MessageBox.Show("Campo deve ser numerico!");
                txtPontoPedido.Focus();
                txtPontoPedido.Text = "";

                return false;
            }

            if (txtPontoPedido.Text == "")
            {
                MessageBox.Show("Campo deve ser preenchido");
                return false;
            }

            ////////////////////////////////////////////////////////////////////////////////////
            ///

            if (int.TryParse(txtIntervalorPedido.Text, out n1) == false)
            {
                MessageBox.Show("Campo deve ser numerico!");
                txtIntervalorPedido.Focus();
                txtIntervalorPedido.Text = "";

                return false;
            }

            if (txtIntervalorPedido.Text == "")
            {
                MessageBox.Show("Campo deve ser preenchido");
                return false;
            }

            ////////////////////////////////////////////////////////////////////////////////////
            ///


            if (int.TryParse(txtLec.Text, out n1) == false)
            {
                MessageBox.Show("Campo deve ser numerico!");
                txtLec.Focus();
                txtLec.Text = "";

                return false;
            }

            if (txtLec.Text == "")
            {
                MessageBox.Show("Campo deve ser preenchido");
                return false;
            }
            return true;
        }

      
           
       

        private void btnExportCsv_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "CSV files (*.csv)|*.csv";
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                using (StreamWriter sw = new StreamWriter(sfd.FileName))
                {
                    using (SqlConnection conn = new SqlConnection(strConexao))
                    {
                        conn.Open();
                        SqlCommand cmd = new SqlCommand("SELECT * FROM parametro_de_estoque", conn);
                        SqlDataReader reader = cmd.ExecuteReader();
                        while (reader.Read())
                        {
                            string linha = $"{reader["id_produto"]};{reader["estoque_de_seguranca_parametro_de_estoque"]};{reader["estoque_maximo_parametro_de_estoque"]};{reader["estoque_medio_parametro_de_estoque"]};{reader["ponto_de_pedido_parametro_de_estoque"]};{reader["intervalo_entre_pedido_parametro_de_estoque"]};{reader["lote_economico_de_compra_parametro_de_estoque"]}";
                            sw.WriteLine(linha);
                        }
                    }
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (ValidarDados() == false)
            {
                return;
            }

            string sql = "insert into parametro_de_estoque" +
                 "(" +
                    "id_produto, " +
                     "estoque_de_seguranca_parametro_de_estoque," +
                     "estoque_maximo_parametro_de_estoque," +
                     "estoque_medio_parametro_de_estoque," +
                     "ponto_de_pedido_parametro_de_estoque," +
                     "intervalo_entre_pedido_parametro_de_estoque," +
                     "intervalo_de_tempo_parametro_de_estoque," +
                     "lote_economico_de_compra_parametro_de_estoque," +
                     "obs_parametro_de_estoque," +
                     "status_parametro_de_estoque" +
                 ")" +
                 "values" +
                 "(" +
                     "'" + cbValorProduto.Text + "', " +
                     "'" + txtEstoqueSeguranca.Text + "'," +
                     "'" + txtEstoqueMaximo.Text + "'," +
                     "'" + txtEstoqueMedio.Text + "'," +
                     "'" + txtPontoPedido.Text + "'," +
                     "'" + txtIntervalorPedido.Text + "'," +
                     "'" + txtLec.Text + "'," +
                     "'" + txtObs.Text + "'," +
                     "'" + cboStatus.Text + "'" +
                 ")select SCOPE_IDENTITY()";

            SqlConnection conexao = new SqlConnection(strConexao);
            SqlCommand cmd = new SqlCommand(sql, conexao);
            cmd.CommandType = CommandType.Text;
            SqlDataReader reader;
            conexao.Open();

            try
            {
                reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    MessageBox.Show("Cadastro realizado com sucesso");

                    btnLimpar.PerformClick();
                    txtId.Text = reader[0].ToString();
                    btnPesquisar.PerformClick();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());

            }
            finally
            {
                conexao.Close();
            }
        }

        private void btnAlterar_Click_1(object sender, EventArgs e)
        {
            string sql = "update parametro_de_estoque set " +
               "id_produto = '" + cbValorProduto.Text + "', " +
               "estoque_de_seguranca_parametro_de_estoque = '" + txtEstoqueSeguranca.Text + "'," +
               "estoque_maximo_parametro_de_estoque = '" + txtEstoqueMaximo.Text + "', " +
               "estoque_medio_parametro_de_estoque = '" + txtEstoqueMedio.Text + "', " +
               "ponto_de_pedido_parametro_de_estoque = '" + txtPontoPedido.Text + "', " +
               "intervalo_entre_pedido_parametro_de_estoque = '" + txtLec.Text + "', " +
               "intervalo_de_tempo_parametro_de_estoque = '" + txtIntervalorPedido.Text + "', " +
               "obs_parametro_de_estoque = '" + txtObs.Text + "', " +
               "status_parametro_de_estoque = '" + txtObs.Text + "' " +
               "where id_parametro = " + txtId.Text;


            SqlConnection conn = new SqlConnection(strConexao);
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.CommandType = CommandType.Text;

            try
            {
                conn.Open();

                int i = cmd.ExecuteNonQuery();
                if (i == 1)
                {
                    MessageBox.Show("Alteração feita com sucesso");

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro: " + ex.ToString());
            }
            finally
            {
                conn.Close();
            }
        }

        private void btnPesquisar_Click_1(object sender, EventArgs e)
        {
            string sql = "select * from parametro_de_estoque where id_parametro =" + txtId.Text;

            SqlConnection conexao = new SqlConnection(strConexao);
            SqlCommand cmd = new SqlCommand(sql, conexao);
            cmd.CommandType = CommandType.Text;
            SqlDataReader reader;
            conexao.Open();

            try
            {
                reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    txtId.Text = reader[0].ToString();
                    cboIdProduto.Text = reader[1].ToString();
                    txtEstoqueSeguranca.Text = reader[2].ToString();
                    txtEstoqueMaximo.Text = reader[3].ToString();
                    txtEstoqueMedio.Text = reader[4].ToString();
                    txtPontoPedido.Text = reader[5].ToString();
                    txtIntervalorPedido.Text = reader[6].ToString();
                    txtLec.Text = reader[7].ToString();

                    txtObs.Text = reader[8].ToString();
                    cboStatus.Text = reader[9].ToString();

                }
                else
                {
                    MessageBox.Show("Código do usuario inexistente!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                conexao.Close();
            }
        }

        private void btnLimpar_Click_1(object sender, EventArgs e)
        {
            txtId.Text = "";
            cboIdProduto.Text = "";
            txtEstoqueSeguranca.Text = "";
            txtEstoqueMaximo.Text = "";
            txtEstoqueMedio.Text = "";
            txtIntervalorPedido.Text = "";
            txtLec.Text = "";
            txtObs.Text = "";
            cboStatus.Text = "";
            txtPontoPedido.Text = "";
        }

        private void btnExcluir_Click_2(object sender, EventArgs e)
        {
            string sql = "delete from parametro_de_estoque where id_parametro =" + txtId.Text;
            SqlConnection conn = new SqlConnection(strConexao);
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.CommandType = CommandType.Text;

            try
            {
                conn.Open();

                int i = cmd.ExecuteNonQuery();
                if (i > 0)
                {
                    MessageBox.Show("Cadastro excluido sucesso");
                    btnLimpar.PerformClick();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro: " + ex.ToString);

            }
            finally
            {
                conn.Close();
            }
        }

        private void btnExportCsv_Click_1(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "CSV files (*.csv)|*.csv";
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                using (StreamWriter sw = new StreamWriter(sfd.FileName))
                {
                    using (SqlConnection conn = new SqlConnection(strConexao))
                    {
                        conn.Open();
                        SqlCommand cmd = new SqlCommand("SELECT * FROM parametro_de_estoque", conn);
                        SqlDataReader reader = cmd.ExecuteReader();
                        while (reader.Read())
                        {
                            string linha = $"{reader["id_produto"]};{reader["estoque_de_seguranca_parametro_de_estoque"]};{reader["estoque_maximo_parametro_de_estoque"]};{reader["estoque_medio_parametro_de_estoque"]};{reader["ponto_de_pedido_parametro_de_estoque"]};{reader["intervalo_entre_pedido_parametro_de_estoque"]};{reader["lote_economico_de_compra_parametro_de_estoque"]}";
                            sw.WriteLine(linha);
                        }
                    }
                }
            }
        }

        private void btnFechar_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtObs_TextChanged(object sender, EventArgs e)
        {

        }

        private void parametroEstoque_Load(object sender, EventArgs e)
        {

        }
    }
    }
    

