﻿namespace CEstoque
{
    partial class FormCalculoEstoque
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblProdutoId = new System.Windows.Forms.Label();
            this.txtProdutoId = new System.Windows.Forms.TextBox();
            this.btnCalcularEstoque = new System.Windows.Forms.Button();
            this.lblEstoqueSeguranca = new System.Windows.Forms.Label();
            this.txtEstoqueSeguranca = new System.Windows.Forms.TextBox();
            this.txtEstoqueMaximo = new System.Windows.Forms.TextBox();
            this.lblEstoqueMaximo = new System.Windows.Forms.Label();
            this.txtEstoqueMedio = new System.Windows.Forms.TextBox();
            this.lblEstoqueMedio = new System.Windows.Forms.Label();
            this.txtPontoPedido = new System.Windows.Forms.TextBox();
            this.lblPontoPedido = new System.Windows.Forms.Label();
            this.txtIntervaloEntrePedidos = new System.Windows.Forms.TextBox();
            this.lblIntervaloEntrePedidos = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtLoteEconomico = new System.Windows.Forms.TextBox();
            this.btnExportarCSV = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblProdutoId
            // 
            this.lblProdutoId.AutoSize = true;
            this.lblProdutoId.Location = new System.Drawing.Point(70, 63);
            this.lblProdutoId.Name = "lblProdutoId";
            this.lblProdutoId.Size = new System.Drawing.Size(110, 20);
            this.lblProdutoId.TabIndex = 0;
            this.lblProdutoId.Text = "ID do Produto: ";
            // 
            // txtProdutoId
            // 
            this.txtProdutoId.Location = new System.Drawing.Point(186, 63);
            this.txtProdutoId.Name = "txtProdutoId";
            this.txtProdutoId.Size = new System.Drawing.Size(176, 27);
            this.txtProdutoId.TabIndex = 1;
            // 
            // btnCalcularEstoque
            // 
            this.btnCalcularEstoque.Location = new System.Drawing.Point(382, 57);
            this.btnCalcularEstoque.Name = "btnCalcularEstoque";
            this.btnCalcularEstoque.Size = new System.Drawing.Size(107, 39);
            this.btnCalcularEstoque.TabIndex = 2;
            this.btnCalcularEstoque.Text = "Calcular";
            this.btnCalcularEstoque.UseVisualStyleBackColor = true;
            this.btnCalcularEstoque.Click += new System.EventHandler(this.btnCalcularEstoque_Click);
            // 
            // lblEstoqueSeguranca
            // 
            this.lblEstoqueSeguranca.AutoSize = true;
            this.lblEstoqueSeguranca.Location = new System.Drawing.Point(70, 145);
            this.lblEstoqueSeguranca.Name = "lblEstoqueSeguranca";
            this.lblEstoqueSeguranca.Size = new System.Drawing.Size(159, 20);
            this.lblEstoqueSeguranca.TabIndex = 3;
            this.lblEstoqueSeguranca.Text = "Estoque de Segurança:";
            // 
            // txtEstoqueSeguranca
            // 
            this.txtEstoqueSeguranca.Location = new System.Drawing.Point(283, 139);
            this.txtEstoqueSeguranca.Name = "txtEstoqueSeguranca";
            this.txtEstoqueSeguranca.Size = new System.Drawing.Size(176, 27);
            this.txtEstoqueSeguranca.TabIndex = 4;
            // 
            // txtEstoqueMaximo
            // 
            this.txtEstoqueMaximo.Location = new System.Drawing.Point(283, 181);
            this.txtEstoqueMaximo.Name = "txtEstoqueMaximo";
            this.txtEstoqueMaximo.Size = new System.Drawing.Size(176, 27);
            this.txtEstoqueMaximo.TabIndex = 6;
            // 
            // lblEstoqueMaximo
            // 
            this.lblEstoqueMaximo.AutoSize = true;
            this.lblEstoqueMaximo.Location = new System.Drawing.Point(70, 187);
            this.lblEstoqueMaximo.Name = "lblEstoqueMaximo";
            this.lblEstoqueMaximo.Size = new System.Drawing.Size(123, 20);
            this.lblEstoqueMaximo.TabIndex = 5;
            this.lblEstoqueMaximo.Text = "Estoque Máximo:";
            // 
            // txtEstoqueMedio
            // 
            this.txtEstoqueMedio.Location = new System.Drawing.Point(283, 223);
            this.txtEstoqueMedio.Name = "txtEstoqueMedio";
            this.txtEstoqueMedio.Size = new System.Drawing.Size(176, 27);
            this.txtEstoqueMedio.TabIndex = 8;
            // 
            // lblEstoqueMedio
            // 
            this.lblEstoqueMedio.AutoSize = true;
            this.lblEstoqueMedio.Location = new System.Drawing.Point(70, 229);
            this.lblEstoqueMedio.Name = "lblEstoqueMedio";
            this.lblEstoqueMedio.Size = new System.Drawing.Size(112, 20);
            this.lblEstoqueMedio.TabIndex = 7;
            this.lblEstoqueMedio.Text = "Estoque Médio:";
            // 
            // txtPontoPedido
            // 
            this.txtPontoPedido.Location = new System.Drawing.Point(283, 265);
            this.txtPontoPedido.Name = "txtPontoPedido";
            this.txtPontoPedido.Size = new System.Drawing.Size(176, 27);
            this.txtPontoPedido.TabIndex = 10;
            // 
            // lblPontoPedido
            // 
            this.lblPontoPedido.AutoSize = true;
            this.lblPontoPedido.Location = new System.Drawing.Point(70, 271);
            this.lblPontoPedido.Name = "lblPontoPedido";
            this.lblPontoPedido.Size = new System.Drawing.Size(121, 20);
            this.lblPontoPedido.TabIndex = 9;
            this.lblPontoPedido.Text = "Ponto de Pedido:";
            // 
            // txtIntervaloEntrePedidos
            // 
            this.txtIntervaloEntrePedidos.Location = new System.Drawing.Point(282, 307);
            this.txtIntervaloEntrePedidos.Name = "txtIntervaloEntrePedidos";
            this.txtIntervaloEntrePedidos.Size = new System.Drawing.Size(176, 27);
            this.txtIntervaloEntrePedidos.TabIndex = 12;
            // 
            // lblIntervaloEntrePedidos
            // 
            this.lblIntervaloEntrePedidos.AutoSize = true;
            this.lblIntervaloEntrePedidos.Location = new System.Drawing.Point(68, 313);
            this.lblIntervaloEntrePedidos.Name = "lblIntervaloEntrePedidos";
            this.lblIntervaloEntrePedidos.Size = new System.Drawing.Size(164, 20);
            this.lblIntervaloEntrePedidos.TabIndex = 11;
            this.lblIntervaloEntrePedidos.Text = "Intervalo entre Pedidos:";
            this.lblIntervaloEntrePedidos.Click += new System.EventHandler(this.label1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(65, 348);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(207, 20);
            this.label1.TabIndex = 13;
            this.label1.Text = "Lote Econômico de Compras: ";
            // 
            // txtLoteEconomico
            // 
            this.txtLoteEconomico.Location = new System.Drawing.Point(280, 345);
            this.txtLoteEconomico.Name = "txtLoteEconomico";
            this.txtLoteEconomico.Size = new System.Drawing.Size(176, 27);
            this.txtLoteEconomico.TabIndex = 14;
            // 
            // btnExportarCSV
            // 
            this.btnExportarCSV.Location = new System.Drawing.Point(320, 399);
            this.btnExportarCSV.Name = "btnExportarCSV";
            this.btnExportarCSV.Size = new System.Drawing.Size(107, 39);
            this.btnExportarCSV.TabIndex = 15;
            this.btnExportarCSV.Text = "Exportar CSV";
            this.btnExportarCSV.UseVisualStyleBackColor = true;
            this.btnExportarCSV.Click += new System.EventHandler(this.btnExportarCSV_Click);
            // 
            // FormCalculoEstoque
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnExportarCSV);
            this.Controls.Add(this.txtLoteEconomico);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtIntervaloEntrePedidos);
            this.Controls.Add(this.lblIntervaloEntrePedidos);
            this.Controls.Add(this.txtPontoPedido);
            this.Controls.Add(this.lblPontoPedido);
            this.Controls.Add(this.txtEstoqueMedio);
            this.Controls.Add(this.lblEstoqueMedio);
            this.Controls.Add(this.txtEstoqueMaximo);
            this.Controls.Add(this.lblEstoqueMaximo);
            this.Controls.Add(this.txtEstoqueSeguranca);
            this.Controls.Add(this.lblEstoqueSeguranca);
            this.Controls.Add(this.btnCalcularEstoque);
            this.Controls.Add(this.txtProdutoId);
            this.Controls.Add(this.lblProdutoId);
            this.Name = "FormCalculoEstoque";
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lblProdutoId;
        private TextBox txtProdutoId;
        private Button btnCalcularEstoque;
        private Label lblEstoqueSeguranca;
        private TextBox txtEstoqueSeguranca;
        private TextBox txtEstoqueMaximo;
        private Label lblEstoqueMaximo;
        private TextBox txtEstoqueMedio;
        private Label lblEstoqueMedio;
        private TextBox txtPontoPedido;
        private Label lblPontoPedido;
        private TextBox txtIntervaloEntrePedidos;
        private Label lblIntervaloEntrePedidos;
        private Label label1;
        private TextBox txtLoteEconomico;
        private Button btnExportarCSV;
    }
}