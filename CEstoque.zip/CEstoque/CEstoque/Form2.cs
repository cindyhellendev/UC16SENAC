﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace CEstoque
{
    public partial class FormCalculoEstoque : Form
    {
        // Defina a string de conexão aqui
        private string connectionString = "Server=localhost;Database=EstoqueDB;User Id=sa;Password=123456;";

        public FormCalculoEstoque()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnCalcularEstoque_Click(object sender, EventArgs e)
        {
            int produtoId = int.Parse(txtProdutoId.Text);
            // Obter dados de demanda e nível de serviço do banco de dados
            List<int> demandas = new List<int>();
            float nivelServico = 0;

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("SELECT Quantidade FROM Demanda WHERE ProdutoId = @ProdutoId", conn);
                cmd.Parameters.AddWithValue("@ProdutoId", produtoId);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    demandas.Add(reader.GetInt32(0));
                }
                reader.Close();

                cmd = new SqlCommand("SELECT NivelServico FROM Produtos WHERE Id = @ProdutoId", conn);
                cmd.Parameters.AddWithValue("@ProdutoId", produtoId);
                nivelServico = Convert.ToSingle(cmd.ExecuteScalar());
            }

            // Cálculos
            double mediaDemanda = demandas.Average();
            double desvioPadraoDemanda = Math.Sqrt(demandas.Average(v => Math.Pow(v - mediaDemanda, 2)));
            double estoqueSeguranca = desvioPadraoDemanda * nivelServico; // Fórmula simplificada
            double estoqueMaximo = mediaDemanda + estoqueSeguranca;
            double estoqueMedio = (estoqueMaximo + estoqueSeguranca) / 2;
            double pontoPedido = mediaDemanda * 2; // Supondo lead time de 2 períodos
            double intervaloEntrePedidos = 1; // Supondo um pedido por período
            double loteEconomico = Math.Sqrt(2 * mediaDemanda * 100 / 5); // Fórmula de Wilson simplificada

            // Salvar parâmetros calculados no banco de dados
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO ParametrosEstoque (ProdutoId, EstoqueSeguranca, EstoqueMaximo, EstoqueMedio, PontoPedido, IntervaloEntrePedidos, LoteEconomico) VALUES (@ProdutoId, @EstoqueSeguranca, @EstoqueMaximo, @EstoqueMedio, @PontoPedido, @IntervaloEntrePedidos, @LoteEconomico)", conn);
                cmd.Parameters.AddWithValue("@ProdutoId", produtoId);
                cmd.Parameters.AddWithValue("@EstoqueSeguranca", estoqueSeguranca);
                cmd.Parameters.AddWithValue("@EstoqueMaximo", estoqueMaximo);
                cmd.Parameters.AddWithValue("@EstoqueMedio", estoqueMedio);
                cmd.Parameters.AddWithValue("@PontoPedido", pontoPedido);
                cmd.Parameters.AddWithValue("@IntervaloEntrePedidos", intervaloEntrePedidos);
                cmd.Parameters.AddWithValue("@LoteEconomico", loteEconomico);
                cmd.ExecuteNonQuery();
            }

            // Mostrar resultados na tela
            txtEstoqueSeguranca.Text = estoqueSeguranca.ToString();
            txtEstoqueMaximo.Text = estoqueMaximo.ToString();
            txtEstoqueMedio.Text = estoqueMedio.ToString();
            txtPontoPedido.Text = pontoPedido.ToString();
            txtIntervaloEntrePedidos.Text = intervaloEntrePedidos.ToString();
            txtLoteEconomico.Text = loteEconomico.ToString();
        }

        private void btnExportarCSV_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                using (StreamWriter sw = new StreamWriter(sfd.FileName))
                {
                    using (SqlConnection conn = new SqlConnection(connectionString))
                    {
                        conn.Open();
                        SqlCommand cmd = new SqlCommand("SELECT * FROM ParametrosEstoque", conn);
                        SqlDataReader reader = cmd.ExecuteReader();
                        while (reader.Read())
                        {
                            string linha = $"{reader["ProdutoId"]},{reader["EstoqueSeguranca"]},{reader["EstoqueMaximo"]},{reader["EstoqueMedio"]},{reader["PontoPedido"]},{reader["IntervaloEntrePedidos"]},{reader["LoteEconomico"]}";
                            sw.WriteLine(linha);
                        }
                    }
                }
            }
        }
    }
}
