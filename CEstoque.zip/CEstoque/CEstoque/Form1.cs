using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Windows.Forms;

namespace CEstoque
{
    public partial class FormProduto : Form
    {
        // Defina a string de conex�o aqui
        private string connectionString = "Server=localhost;Database=EstoqueDB;User Id=sa;Password=123456;";

        public FormProduto()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnSalvarProduto_Click(object sender, EventArgs e)
        {
            string codigo = txtCodigo.Text;
            string descricao = txtDescricao.Text;
            string codigoBarras = txtCodigoBarras.Text;
            float nivelServico = float.Parse(txtNivelServico.Text);

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO Produtos (Codigo, Descricao, CodigoBarras, NivelServico) VALUES (@Codigo, @Descricao, @CodigoBarras, @NivelServico)", conn);
                cmd.Parameters.AddWithValue("@Codigo", codigo);
                cmd.Parameters.AddWithValue("@Descricao", descricao);
                cmd.Parameters.AddWithValue("@CodigoBarras", codigoBarras);
                cmd.Parameters.AddWithValue("@NivelServico", nivelServico);
                cmd.ExecuteNonQuery();
            }
        }

        private void btnImportarDemanda_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                string[] lines = File.ReadAllLines(ofd.FileName);
                foreach (string line in lines)
                {
                    string[] data = line.Split(',');
                    int produtoId = int.Parse(data[0]);
                    for (int i = 1; i <= 6; i++)
                    {
                        int quantidade = int.Parse(data[i]);
                        using (SqlConnection conn = new SqlConnection(connectionString))
                        {
                            conn.Open();
                            SqlCommand cmd = new SqlCommand("INSERT INTO Demanda (ProdutoId, Periodo, Quantidade) VALUES (@ProdutoId, @Periodo, @Quantidade)", conn);
                            cmd.Parameters.AddWithValue("@ProdutoId", produtoId);
                            cmd.Parameters.AddWithValue("@Periodo", i);
                            cmd.Parameters.AddWithValue("@Quantidade", quantidade);
                            cmd.ExecuteNonQuery();
                        }
                    }
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

            FormCalculoEstoque param = new FormCalculoEstoque();
            param.Show();

            this.Hide();

        }
    }
}
